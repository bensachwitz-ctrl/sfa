"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import TopBar from "@/components/TopBar";
import StatCard from "@/components/StatCard";
import type { Company } from "@/lib/mockData";
import {
  Building2, Search, ChevronRight, Loader2, Truck,
  AlertCircle, CheckCircle2, ShieldAlert, Activity,
  ArrowUpDown, X,
} from "lucide-react";
import clsx from "clsx";

function fmt(n: number) {
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(2)}M`;
  if (n >= 1_000) return `$${(n / 1_000).toFixed(0)}K`;
  return `$${Math.round(n)}`;
}

function RiskBar({ score }: { score: number }) {
  const color =
    score >= 70 ? "bg-red-500" :
    score >= 45 ? "bg-amber-500" :
    score >= 20 ? "bg-yellow-500" :
    "bg-green-500";
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 bg-slate-700 rounded-full h-1.5 w-16">
        <div className={`h-1.5 rounded-full ${color}`} style={{ width: `${score}%` }} />
      </div>
      <span className={clsx("text-xs font-bold tabular-nums w-6 text-right",
        score >= 70 ? "text-red-400" :
        score >= 45 ? "text-amber-400" :
        score >= 20 ? "text-yellow-400" : "text-green-400")}>
        {score}
      </span>
    </div>
  );
}

function saferBadge(rating: string) {
  if (!rating || rating === "Unknown" || rating === "None" || rating === "Not Found") {
    return <span className="text-slate-500 text-xs">—</span>;
  }
  const isGood = rating.toLowerCase().includes("satisfactory") &&
    !rating.toLowerCase().includes("un");
  const isBad = rating.toLowerCase().includes("unsatisfactory") ||
    rating.toLowerCase().includes("conditional");
  return (
    <span className={clsx(
      "text-[10px] px-2 py-0.5 rounded-full border font-medium",
      isGood ? "text-green-400 bg-green-900/20 border-green-700/40" :
      isBad ? "text-amber-400 bg-amber-900/20 border-amber-700/40" :
      "text-slate-400 bg-slate-700/40 border-slate-600/40"
    )}>
      {rating.length > 20 ? rating.slice(0, 18) + "…" : rating}
    </span>
  );
}

type SortKey = "risk" | "incurred" | "open" | "name" | "claims";

export default function CompaniesPage() {
  const router = useRouter();
  const [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState<SortKey>("risk");
  const [filterLine, setFilterLine] = useState("All");

  useEffect(() => {
    fetch("/api/companies")
      .then((r) => r.json())
      .then((d) => { setCompanies(d); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const filtered = companies
    .filter((c) => {
      const q = search.toLowerCase();
      if (!q) return true;
      return (
        c.accountName.toLowerCase().includes(q) ||
        (c.dotNumber && c.dotNumber.includes(q))
      );
    })
    .filter((c) => {
      if (filterLine === "All") return true;
      return c.topLine === filterLine;
    })
    .sort((a, b) => {
      if (sortBy === "risk") return (b.riskScore ?? 0) - (a.riskScore ?? 0);
      if (sortBy === "incurred") return (b.totalIncurred ?? 0) - (a.totalIncurred ?? 0);
      if (sortBy === "open") return (b.openClaims ?? 0) - (a.openClaims ?? 0);
      if (sortBy === "claims") return (b.totalClaims ?? 0) - (a.totalClaims ?? 0);
      return a.accountName.localeCompare(b.accountName);
    });

  const withOpenClaims = companies.filter((c) => (c.openClaims ?? 0) > 0).length;
  const totalIncurred = companies.reduce((s, c) => s + (c.totalIncurred ?? 0), 0);
  const openCount = companies.reduce((s, c) => s + (c.openClaims ?? 0), 0);
  const highRisk = companies.filter((c) => (c.riskScore ?? 0) >= 60).length;

  return (
    <>
      <TopBar
        title="Companies & DOT"
        subtitle="77 insureds · click any company to see claims history and SAFER data"
      />

      <main className="page-body space-y-6">
        {/* ── KPIs ────────────────────────────────────────────────────────── */}
        <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
          <StatCard
            label="Total Companies"
            value={companies.length || "—"}
            subtext="Active insureds"
            icon={Building2}
            variant="default"
          />
          <StatCard
            label="Companies w/ Open Claims"
            value={withOpenClaims || "—"}
            subtext={`${openCount} total open claims`}
            icon={AlertCircle}
            variant={withOpenClaims > 10 ? "warning" : "default"}
          />
          <StatCard
            label="Total Incurred (Portfolio)"
            value={totalIncurred ? fmt(totalIncurred) : "—"}
            subtext="All companies · all time"
            icon={Activity}
            variant="default"
          />
          <StatCard
            label="High-Risk Companies"
            value={highRisk || "—"}
            subtext="Risk score ≥ 60"
            icon={ShieldAlert}
            variant={highRisk > 5 ? "danger" : "warning"}
          />
        </div>

        {/* ── Filters ─────────────────────────────────────────────────────── */}
        <div className="card-padded">
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex-1 min-w-[180px] max-w-sm">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                placeholder="Search name or DOT #…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full bg-slate-700 border border-slate-600 text-slate-200 text-sm rounded-xl pl-10 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-teal-500/60"
              />
            </div>

            <div className="h-5 w-px bg-slate-700 hidden sm:block" />

            {/* Line filter */}
            <div className="flex items-center gap-1.5 flex-wrap">
              {["All", "AL", "GL", "APD"].map((l) => (
                <button
                  key={l}
                  onClick={() => setFilterLine(l)}
                  className={clsx(
                    "px-3 py-1.5 rounded-full text-xs font-medium transition-colors",
                    filterLine === l
                      ? "bg-teal-600 text-white"
                      : "bg-slate-700 text-slate-400 hover:bg-slate-600"
                  )}
                >
                  {l === "All" ? "All Lines" :
                   l === "AL" ? "Auto Liability" :
                   l === "GL" ? "Gen. Liability" :
                   "Phys. Damage"}
                </button>
              ))}
            </div>

            <div className="h-5 w-px bg-slate-700 hidden md:block" />

            {/* Sort */}
            <div className="flex items-center gap-1.5">
              <ArrowUpDown className="w-3 h-3 text-slate-500" />
              {(
                [
                  { key: "risk" as SortKey, label: "Risk" },
                  { key: "incurred" as SortKey, label: "Incurred" },
                  { key: "open" as SortKey, label: "Open Claims" },
                  { key: "claims" as SortKey, label: "Total Claims" },
                  { key: "name" as SortKey, label: "Name" },
                ] as { key: SortKey; label: string }[]
              ).map(({ key, label }) => (
                <button
                  key={key}
                  onClick={() => setSortBy(key)}
                  className={clsx(
                    "px-2.5 py-1 rounded-md text-xs transition-colors",
                    sortBy === key
                      ? "bg-slate-600 text-slate-200"
                      : "text-slate-500 hover:text-slate-300"
                  )}
                >
                  {label}
                </button>
              ))}
            </div>

            {search && (
              <button
                onClick={() => setSearch("")}
                className="flex items-center gap-1 text-slate-500 hover:text-red-400 text-xs ml-auto"
              >
                <X className="w-3 h-3" /> Clear
              </button>
            )}

            <span className="text-slate-600 text-xs hidden lg:block ml-auto">
              {filtered.length} of {companies.length} companies
            </span>
          </div>
        </div>

        {/* ── Company List ─────────────────────────────────────────────────── */}
        {loading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="w-7 h-7 animate-spin text-teal-400" />
          </div>
        ) : (
          <div className="space-y-1.5">
            {filtered.length === 0 && (
              <div className="card-padded text-center text-slate-500 py-10">
                No companies match your search.
              </div>
            )}

            {/* Column headers */}
            {filtered.length > 0 && (
              <div className="hidden lg:grid grid-cols-[1fr_80px_80px_100px_80px_90px_80px_40px] gap-3 px-4 py-1.5">
                {["Company", "DOT", "SAFER", "Incurred", "Open", "Claims", "Risk", ""].map((h) => (
                  <div key={h} className="text-slate-500 text-[10px] font-medium uppercase tracking-wider">
                    {h}
                  </div>
                ))}
              </div>
            )}

            {filtered.map((c) => {
              const risk = (c.riskScore ?? 0);
              const borderColor =
                risk >= 70 ? "border-l-red-500" :
                risk >= 45 ? "border-l-amber-500" :
                risk >= 20 ? "border-l-yellow-600" :
                "border-l-teal-600";
              return (
                <button
                  key={c.id}
                  onClick={() => router.push(`/companies/${encodeURIComponent(c.id)}`)}
                  className={clsx(
                    "w-full text-left card-padded hover:bg-slate-700/40 active:scale-[0.998] transition-all group border-l-4",
                    borderColor
                  )}
                >
                  <div className="flex items-center gap-3 flex-wrap lg:grid lg:grid-cols-[1fr_80px_80px_100px_80px_90px_80px_40px]">
                    {/* Name */}
                    <div className="flex items-center gap-3 min-w-[200px] flex-1 lg:flex-none">
                      <div className="w-8 h-8 rounded-lg bg-slate-700 flex items-center justify-center shrink-0">
                        <Building2 className="w-4 h-4 text-teal-400" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-slate-200 font-semibold text-sm truncate group-hover:text-white transition-colors">
                          {c.accountName}
                        </p>
                        <p className="text-slate-500 text-[10px] flex items-center gap-1 mt-0.5">
                          {c.topLine && (
                            <span className={clsx("font-medium",
                              c.topLine === "AL" ? "text-teal-500" :
                              c.topLine === "GL" ? "text-purple-500" :
                              "text-orange-500"
                            )}>
                              {c.topLine}
                            </span>
                          )}
                          {c.topLine && c.topCategory && <span>·</span>}
                          <span className="truncate max-w-[160px]">{c.topCategory}</span>
                        </p>
                      </div>
                    </div>

                    {/* DOT */}
                    <div>
                      {c.dotNumber ? (
                        <span className="flex items-center gap-1 text-slate-400 text-xs">
                          <Truck className="w-3 h-3 shrink-0" />{c.dotNumber}
                        </span>
                      ) : (
                        <span className="text-slate-600 text-xs">—</span>
                      )}
                    </div>

                    {/* SAFER */}
                    <div>{saferBadge(c.saferRating ?? "")}</div>

                    {/* Incurred */}
                    <div>
                      <p className="text-slate-200 text-sm font-semibold">
                        {c.totalIncurred ? fmt(c.totalIncurred) : "—"}
                      </p>
                    </div>

                    {/* Open claims */}
                    <div>
                      {(c.openClaims ?? 0) > 0 ? (
                        <span className="text-xs font-semibold text-red-400">
                          {c.openClaims}
                        </span>
                      ) : (
                        <span className="text-slate-500 text-xs">0</span>
                      )}
                    </div>

                    {/* Total claims */}
                    <div>
                      <span className="text-slate-300 text-sm font-medium">
                        {c.totalClaims ?? "—"}
                      </span>
                    </div>

                    {/* Risk score bar */}
                    <div className="min-w-[80px]">
                      <RiskBar score={risk} />
                    </div>

                    {/* Arrow */}
                    <div className="flex justify-end">
                      <ChevronRight className="w-4 h-4 text-slate-600 group-hover:text-teal-400 transition-colors" />
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </main>
    </>
  );
}
