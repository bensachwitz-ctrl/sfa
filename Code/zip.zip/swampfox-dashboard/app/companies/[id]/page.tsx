"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import TopBar from "@/components/TopBar";
import ClaimsByYearChart from "@/components/charts/ClaimsByYearChart";
import ClaimsByCategoryChart from "@/components/charts/ClaimsByCategoryChart";
import LineOfBusinessChart from "@/components/charts/LineOfBusinessChart";
import PortfolioIncurredChart from "@/components/charts/PortfolioIncurredChart";
import {
  ArrowLeft, Building2, Truck, FileText, ExternalLink,
  Loader2, AlertTriangle, MapPin, Activity, ShieldCheck,
  ShieldAlert, AlertCircle, ChevronDown, ChevronUp,
} from "lucide-react";
import clsx from "clsx";

// ── Types ─────────────────────────────────────────────────────────────────────

interface ClaimsByYearPoint {
  year: number; count: number; incurred: number; paid: number; reserved: number;
}
interface ClaimsByCategoryPoint { category: string; count: number; incurred: number; }
interface ClaimsByLinePoint { line: string; count: number; incurred: number; }

interface MasterClaim {
  carrier: string; insured: string; policyNumber: string; policyYear: number;
  claimNumber: string; dateOfLoss: string; status: "Open" | "Closed";
  claimType: string; line: string; causeOfLoss: string; category: string;
  totalPaid: number; totalReserve: number; totalIncurred: number;
  accidentDesc: string; driver: string; claimant: string; state: string;
  closeDate: string;
}

interface CompanyData {
  company: {
    id: string; accountName: string; accountCode: string;
    dotNumber?: string; address?: string; saferRating?: string;
    operatingStatus?: string; vehicleInspections?: number;
    vehicleOOSRate?: number | null; driverInspections?: number;
    driverOOSRate?: number | null; openClaims?: number;
    totalIncurred?: number; totalPaid?: number; totalReserved?: number;
    totalClaims?: number; topCategory?: string; topLine?: string;
    carriers?: string[]; states?: string[]; riskScore?: number;
    lastLossDate?: string; firstLossDate?: string;
  } | null;
  claims: MasterClaim[];
  charts: {
    claimsByYear: ClaimsByYearPoint[];
    claimsByCategory: ClaimsByCategoryPoint[];
    claimsByLine: ClaimsByLinePoint[];
  };
  policies: unknown[];
  drivers: unknown[];
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function fmt(n: number) {
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(2)}M`;
  if (n >= 1_000) return `$${(n / 1_000).toFixed(0)}K`;
  return `$${Math.round(n)}`;
}

function ChartCard({
  title, subtitle, children, height = "240px",
}: {
  title: string; subtitle?: string; children: React.ReactNode; height?: string;
}) {
  return (
    <div className="card-padded">
      <div className="mb-4">
        <p className="text-slate-200 font-semibold text-sm">{title}</p>
        {subtitle && <p className="text-slate-500 text-xs mt-0.5">{subtitle}</p>}
      </div>
      <div style={{ height }}>{children}</div>
    </div>
  );
}

const STATUS_COLORS: Record<string, string> = {
  Open: "text-red-400 bg-red-900/30 border-red-700/40",
  Closed: "text-slate-400 bg-slate-700/40 border-slate-600/40",
};

const LINE_COLORS: Record<string, string> = {
  AL: "text-teal-400 bg-teal-900/30 border-teal-700/40",
  GL: "text-purple-400 bg-purple-900/30 border-purple-700/40",
  APD: "text-orange-400 bg-orange-900/30 border-orange-700/40",
};

// ── Page ──────────────────────────────────────────────────────────────────────

export default function CompanyProfilePage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const [data, setData] = useState<CompanyData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showAllClaims, setShowAllClaims] = useState(false);
  const [claimSortField, setClaimSortField] = useState<"date" | "incurred">("date");
  const [statusFilter, setStatusFilter] = useState<"All" | "Open" | "Closed">("All");

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    fetch(`/api/companies/${encodeURIComponent(id)}`)
      .then((r) => {
        if (!r.ok) throw new Error(`${r.status}`);
        return r.json();
      })
      .then((d) => { setData(d); setLoading(false); })
      .catch((e) => { setError(e.message); setLoading(false); });
  }, [id]);

  if (loading) {
    return (
      <>
        <TopBar title="Loading…" />
        <main className="page-body flex items-center justify-center min-h-[60vh]">
          <div className="flex flex-col items-center gap-4">
            <Loader2 className="w-8 h-8 animate-spin text-teal-400" />
            <p className="text-slate-400 text-sm">Loading company profile…</p>
          </div>
        </main>
      </>
    );
  }

  if (error || !data?.company) {
    return (
      <>
        <TopBar title="Not Found" />
        <main className="page-body flex items-center justify-center min-h-[60vh]">
          <div className="flex flex-col items-center gap-4 text-center">
            <AlertTriangle className="w-10 h-10 text-amber-400" />
            <p className="text-slate-300 font-medium">Company not found</p>
            <p className="text-slate-500 text-sm">{decodeURIComponent(id ?? "")}</p>
            <button
              onClick={() => router.push("/companies")}
              className="text-teal-400 text-sm hover:underline"
            >
              ← Back to Companies
            </button>
          </div>
        </main>
      </>
    );
  }

  const { company, claims, charts } = data;
  const name = company.accountName;

  // Filtered + sorted claims for the table
  const filteredClaims = claims
    .filter((c) => statusFilter === "All" || c.status === statusFilter)
    .sort((a, b) =>
      claimSortField === "date"
        ? b.dateOfLoss.localeCompare(a.dateOfLoss)
        : b.totalIncurred - a.totalIncurred
    );
  const displayedClaims = showAllClaims
    ? filteredClaims
    : filteredClaims.slice(0, 20);

  const totalIncurred = claims.reduce((s, c) => s + c.totalIncurred, 0);
  const totalPaid = claims.reduce((s, c) => s + c.totalPaid, 0);
  const totalReserved = claims.reduce((s, c) => s + c.totalReserve, 0);
  const openCount = claims.filter((c) => c.status === "Open").length;

  // Build paid-vs-reserved-by-year for the trend chart
  const paidVsReservedByYear = charts.claimsByYear.map((y) => ({
    year: String(y.year),
    paid: y.paid,
    reserved: y.reserved,
    incurred: y.incurred,
    claims: y.count,
  }));

  const saferRating = company.saferRating ?? "Unknown";
  const riskScore = company.riskScore ?? 0;

  return (
    <>
      <TopBar
        title={name}
        subtitle={
          [
            company.dotNumber ? `DOT #${company.dotNumber}` : null,
            company.address || null,
          ]
            .filter(Boolean)
            .join(" · ") || "Company Profile"
        }
      />

      <main className="page-body space-y-6">
        {/* ── Back ─────────────────────────────────────────────────────────── */}
        <button
          onClick={() => router.push("/companies")}
          className="flex items-center gap-2 text-slate-400 hover:text-teal-400 text-sm transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Back to Companies
        </button>

        {/* ── Company Header ───────────────────────────────────────────────── */}
        <div className="card-padded">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-slate-700 flex items-center justify-center shrink-0">
                <Building2 className="w-6 h-6 text-teal-400" />
              </div>
              <div>
                <h2 className="text-slate-100 font-bold text-xl">{name}</h2>
                <div className="flex flex-wrap items-center gap-3 mt-1.5">
                  {company.dotNumber && (
                    <span className="flex items-center gap-1.5 text-slate-400 text-xs">
                      <Truck className="w-3.5 h-3.5" /> DOT #{company.dotNumber}
                    </span>
                  )}
                  {company.address && (
                    <span className="flex items-center gap-1.5 text-slate-400 text-xs">
                      <MapPin className="w-3.5 h-3.5" /> {company.address}
                    </span>
                  )}
                  {company.states && company.states.length > 0 && (
                    <span className="text-slate-400 text-xs">
                      States: {company.states.join(", ")}
                    </span>
                  )}
                  {company.carriers && company.carriers.length > 0 && (
                    <span className="text-slate-400 text-xs">
                      Carriers: {company.carriers.join(", ")}
                    </span>
                  )}
                </div>

                {/* SAFER + Operating status badges */}
                <div className="flex flex-wrap items-center gap-2 mt-2">
                  {saferRating && saferRating !== "Unknown" && saferRating !== "None" && saferRating !== "Not Found" && (
                    <span className="flex items-center gap-1 text-xs text-slate-400">
                      <ShieldCheck className="w-3.5 h-3.5" /> SAFER:
                      <span className="text-slate-300 font-medium ml-0.5">{saferRating}</span>
                    </span>
                  )}
                  {company.operatingStatus && company.operatingStatus !== "Unknown" && (
                    <span className={clsx(
                      "text-[10px] px-2 py-0.5 rounded-full border",
                      company.operatingStatus.toUpperCase().includes("ACTIVE")
                        ? "text-green-400 bg-green-900/20 border-green-700/30"
                        : "text-slate-400 bg-slate-700/40 border-slate-600/40"
                    )}>
                      {company.operatingStatus.length > 30
                        ? company.operatingStatus.slice(0, 28) + "…"
                        : company.operatingStatus}
                    </span>
                  )}
                  {riskScore >= 60 && (
                    <span className="flex items-center gap-1 text-xs text-red-400">
                      <ShieldAlert className="w-3.5 h-3.5" /> High Risk
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* DOT lookup */}
            {company.dotNumber && (
              <a
                href={`https://safer.fmcsa.dot.gov/query.asp?searchtype=ANY&query_type=queryCarrierSnapshot&query_param=USDOT&query_string=${company.dotNumber}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 text-teal-400 hover:text-teal-300 text-xs border border-teal-700/50 bg-teal-900/20 px-3 py-1.5 rounded-lg transition-colors"
              >
                <ExternalLink className="w-3.5 h-3.5" /> SAFER Lookup
              </a>
            )}
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mt-5 pt-4 border-t border-slate-700/50">
            {[
              {
                label: "Total Claims",
                value: claims.length,
                color: "text-slate-200",
              },
              {
                label: "Open Claims",
                value: openCount,
                color: openCount > 3 ? "text-red-400" : openCount > 0 ? "text-amber-400" : "text-green-400",
              },
              {
                label: "Total Incurred",
                value: fmt(totalIncurred),
                color: "text-orange-400",
              },
              {
                label: "Total Paid",
                value: fmt(totalPaid),
                color: "text-teal-400",
              },
              {
                label: "Open Reserves",
                value: totalReserved > 0 ? fmt(totalReserved) : "$0",
                color: totalReserved > 0 ? "text-amber-400" : "text-slate-500",
              },
            ].map(({ label, value, color }) => (
              <div key={label} className="bg-slate-800/60 rounded-lg p-3">
                <p className="text-slate-500 text-xs mb-1">{label}</p>
                <p className={`text-lg font-bold ${color}`}>{value}</p>
              </div>
            ))}
          </div>

          {/* Inspection data if available */}
          {(company.vehicleInspections ?? 0) > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-3">
              {[
                { label: "Vehicle Inspections", value: company.vehicleInspections },
                {
                  label: "Vehicle OOS Rate",
                  value:
                    company.vehicleOOSRate !== null && company.vehicleOOSRate !== undefined
                      ? `${company.vehicleOOSRate.toFixed(1)}%`
                      : "—",
                  warn: (company.vehicleOOSRate ?? 0) > 15,
                },
                { label: "Driver Inspections", value: company.driverInspections },
                {
                  label: "Driver OOS Rate",
                  value:
                    company.driverOOSRate !== null && company.driverOOSRate !== undefined
                      ? `${company.driverOOSRate.toFixed(1)}%`
                      : "—",
                  warn: (company.driverOOSRate ?? 0) > 10,
                },
              ].map(({ label, value, warn }) => (
                <div key={label} className="bg-slate-800/40 rounded-lg px-3 py-2">
                  <p className="text-slate-500 text-[10px] mb-0.5">{label}</p>
                  <p
                    className={clsx(
                      "text-sm font-semibold",
                      warn ? "text-amber-400" : "text-slate-300"
                    )}
                  >
                    {String(value ?? "—")}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ── Charts ───────────────────────────────────────────────────────── */}
        <section>
          <h2 className="section-header flex items-center gap-2">
            <Activity className="w-4 h-4 text-teal-400" /> Loss Analytics
          </h2>

          {/* Row 1: Claims by year + Line of business */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
            <div className="lg:col-span-2">
              <ChartCard
                title="Claims Volume & Incurred by Year"
                subtitle="Claim count (bars) · total incurred (orange line)"
                height="260px"
              >
                <ClaimsByYearChart data={charts.claimsByYear} />
              </ChartCard>
            </div>
            <div>
              <ChartCard
                title="Line of Business"
                subtitle="Incurred by coverage line"
                height="260px"
              >
                <LineOfBusinessChart data={charts.claimsByLine} mode="incurred" />
              </ChartCard>
            </div>
          </div>

          {/* Row 2: Category breakdown + Paid vs Reserved trend */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <ChartCard
              title="Loss Categories"
              subtitle="Top categories by total incurred"
              height="240px"
            >
              <ClaimsByCategoryChart data={charts.claimsByCategory} mode="incurred" />
            </ChartCard>
            <ChartCard
              title="Paid vs. Reserved — Year Over Year"
              subtitle="Paid losses (teal) · open reserves (amber)"
              height="240px"
            >
              <PortfolioIncurredChart data={paidVsReservedByYear} />
            </ChartCard>
          </div>
        </section>

        {/* ── Samsara placeholder ───────────────────────────────────────────── */}
        <section>
          <h2 className="section-header">Driver & Telematics Data</h2>
          <div className="card-padded border-l-4 border-l-slate-600 bg-slate-800/40">
            <div className="flex items-center gap-3">
              <Truck className="w-5 h-5 text-slate-500 shrink-0" />
              <div>
                <p className="text-slate-300 font-medium text-sm">
                  Samsara telematics not yet connected for this company
                </p>
                <p className="text-slate-500 text-xs mt-0.5">
                  When connected, you will see driver speeding events, hard braking, harsh
                  acceleration, cornering events, and which driver was behind the wheel for
                  each claim. This is the next phase of the integration.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* ── Claims History ────────────────────────────────────────────────── */}
        <section>
          <div className="flex items-center justify-between mb-3">
            <h2 className="section-header mb-0 flex items-center gap-2">
              <FileText className="w-4 h-4 text-amber-400" />
              Claims History ({claims.length})
            </h2>
            <div className="flex items-center gap-2">
              {/* Status filter */}
              {["All", "Open", "Closed"].map((s) => (
                <button
                  key={s}
                  onClick={() => setStatusFilter(s as "All" | "Open" | "Closed")}
                  className={clsx(
                    "px-2.5 py-1 rounded-full text-xs font-medium transition-colors",
                    statusFilter === s
                      ? "bg-teal-600 text-white"
                      : "bg-slate-700 text-slate-400 hover:bg-slate-600"
                  )}
                >
                  {s}
                </button>
              ))}
              {/* Sort toggle */}
              <button
                onClick={() =>
                  setClaimSortField((f) => (f === "date" ? "incurred" : "date"))
                }
                className="flex items-center gap-1 text-slate-500 hover:text-teal-400 text-xs transition-colors ml-1"
              >
                Sort: {claimSortField === "date" ? "Date" : "Incurred"}
              </button>
            </div>
          </div>

          <div className="card overflow-x-auto">
            <table className="w-full text-sm min-w-[780px]">
              <thead>
                <tr className="border-b border-slate-700/60">
                  {[
                    "Claim #",
                    "Line",
                    "Category",
                    "Date of Loss",
                    "State",
                    "Driver",
                    "Status",
                    "Paid",
                    "Reserved",
                    "Incurred",
                  ].map((h) => (
                    <th
                      key={h}
                      className="text-left text-slate-400 text-xs font-medium px-4 py-3"
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {displayedClaims.map((c, i) => (
                  <tr
                    key={c.claimNumber}
                    className={clsx(
                      "border-b border-slate-700/20 hover:bg-slate-800/30 transition-colors",
                      i === displayedClaims.length - 1 && "border-0",
                      c.status === "Open" && "bg-red-950/10"
                    )}
                  >
                    <td className="px-4 py-3 font-mono text-xs text-slate-300">
                      {c.claimNumber}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-[10px] px-1.5 py-0.5 rounded border ${LINE_COLORS[c.line] ?? ""}`}>
                        {c.line}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-slate-300 text-xs max-w-[120px] truncate" title={c.category}>
                      {c.category}
                    </td>
                    <td className="px-4 py-3 text-slate-400 text-xs">{c.dateOfLoss}</td>
                    <td className="px-4 py-3 text-slate-400 text-xs">{c.state}</td>
                    <td className="px-4 py-3 text-slate-400 text-xs max-w-[100px] truncate">
                      {c.driver || "—"}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-[10px] px-2 py-0.5 rounded-full border ${STATUS_COLORS[c.status] ?? ""}`}>
                        {c.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-slate-200 text-xs font-medium">
                      {c.totalPaid > 0 ? fmt(c.totalPaid) : "—"}
                    </td>
                    <td className="px-4 py-3 text-amber-400 text-xs font-medium">
                      {c.totalReserve > 0 ? fmt(c.totalReserve) : "—"}
                    </td>
                    <td className="px-4 py-3 text-orange-400 text-xs font-semibold">
                      {c.totalIncurred > 0 ? fmt(c.totalIncurred) : "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="border-t border-slate-700/60 bg-slate-800/40">
                  <td colSpan={7} className="px-4 py-2.5 text-slate-400 text-xs font-medium">
                    {filteredClaims.length} claims
                    {statusFilter !== "All" ? ` (${statusFilter})` : ""}
                  </td>
                  <td className="px-4 py-2.5 text-teal-400 font-bold text-xs">
                    {fmt(totalPaid)}
                  </td>
                  <td className="px-4 py-2.5 text-amber-400 font-bold text-xs">
                    {totalReserved > 0 ? fmt(totalReserved) : "—"}
                  </td>
                  <td className="px-4 py-2.5 text-orange-400 font-bold text-xs">
                    {fmt(totalIncurred)}
                  </td>
                </tr>
              </tfoot>
            </table>

            {filteredClaims.length > 20 && (
              <div className="border-t border-slate-700/30">
                <button
                  onClick={() => setShowAllClaims((v) => !v)}
                  className="flex items-center justify-center gap-2 w-full py-2.5 text-slate-400 hover:text-teal-400 text-xs transition-colors"
                >
                  {showAllClaims ? (
                    <>
                      <ChevronUp className="w-3.5 h-3.5" /> Show less
                    </>
                  ) : (
                    <>
                      <ChevronDown className="w-3.5 h-3.5" />
                      Show all {filteredClaims.length} claims
                    </>
                  )}
                </button>
              </div>
            )}
          </div>

          {/* Accident descriptions for open claims */}
          {claims.some((c) => c.status === "Open" && c.accidentDesc) && (
            <div className="card-padded mt-3 bg-red-950/10 border border-red-900/20">
              <p className="text-red-400 font-semibold text-xs uppercase tracking-wider mb-3 flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5" /> Open Claim Details
              </p>
              <div className="space-y-3">
                {claims
                  .filter((c) => c.status === "Open" && c.accidentDesc)
                  .map((c) => (
                    <div key={c.claimNumber} className="grid grid-cols-[auto_1fr] gap-3 text-xs">
                      <div className="space-y-0.5">
                        <p className="font-mono text-slate-400">{c.claimNumber}</p>
                        <p className="text-slate-500">{c.dateOfLoss}</p>
                        <p className="text-amber-400 font-medium">{fmt(c.totalIncurred)}</p>
                      </div>
                      <div>
                        <p className="text-slate-300">{c.accidentDesc}</p>
                        {c.driver && (
                          <p className="text-slate-500 mt-0.5">Driver: {c.driver}</p>
                        )}
                        {c.claimant && (
                          <p className="text-slate-500">Claimant: {c.claimant}</p>
                        )}
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}
        </section>
      </main>
    </>
  );
}
