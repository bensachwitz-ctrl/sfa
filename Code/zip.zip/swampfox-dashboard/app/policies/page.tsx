"use client";

import { useState } from "react";
import TopBar from "@/components/TopBar";
import PowerBIReport from "@/components/PowerBIReport";
import StatCard from "@/components/StatCard";
import { REPORTS } from "@/lib/powerbiConfig";
import {
  Shield,
  CalendarClock,
  AlertTriangle,
  BadgeDollarSign,
  ChevronDown,
} from "lucide-react";
import clsx from "clsx";

const COVERAGE_TYPES = [
  "All Coverage",
  "Auto Liability",
  "Physical Damage",
  "Cargo",
  "General Liability",
  "Workers Comp",
  "Commercial Property",
  "Umbrella",
];

const RENEWAL_WINDOWS = [
  "All",
  "Expiring in 7 Days",
  "Expiring in 30 Days",
  "Expiring in 60 Days",
  "Expiring in 90 Days",
];

const STATUS_OPTIONS = ["All", "Active", "Lapsed", "Cancelled", "Pending"];

export default function PoliciesPage() {
  const [coverage, setCoverage] = useState("All Coverage");
  const [renewalWindow, setRenewalWindow] = useState("All");
  const [status, setStatus] = useState("All");

  return (
    <>
      <TopBar
        title="Policies Dashboard"
        subtitle="Active coverage, renewals, and gap analysis"
      />

      <main className="page-body space-y-6">
        {/* ── KPIs ── */}
        <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
          <StatCard
            label="Active Policies"
            value="—"
            subtext="All lines of business"
            icon={Shield}
            variant="default"
          />
          <StatCard
            label="Renewing in 30 Days"
            value="—"
            subtext="Requires agent action"
            icon={CalendarClock}
            variant="warning"
            trend="up"
            trendValue="Review"
          />
          <StatCard
            label="High Claim Activity"
            value="—"
            subtext="Policies with ≥2 open claims"
            icon={AlertTriangle}
            variant="danger"
          />
          <StatCard
            label="Total Premium (YTD)"
            value="—"
            subtext="Written premium"
            icon={BadgeDollarSign}
            variant="success"
          />
        </div>

        {/* ── Filters ── */}
        <div className="card-padded">
          <div className="flex flex-wrap items-center gap-4">
            <span className="text-slate-400 text-sm font-medium">Filters</span>

            {/* Status pills */}
            <div className="flex items-center gap-1.5 flex-wrap">
              {STATUS_OPTIONS.map((s) => (
                <button
                  key={s}
                  onClick={() => setStatus(s)}
                  className={clsx(
                    "px-3 py-1 rounded-full text-xs font-medium transition-colors",
                    status === s
                      ? "bg-teal-600 text-white"
                      : "bg-slate-700 text-slate-400 hover:bg-slate-600 hover:text-slate-200"
                  )}
                >
                  {s}
                </button>
              ))}
            </div>

            <div className="h-4 w-px bg-slate-700 hidden sm:block" />

            {/* Coverage type */}
            <div className="relative">
              <select
                value={coverage}
                onChange={(e) => setCoverage(e.target.value)}
                className="appearance-none bg-slate-700 border border-slate-600 text-slate-300 text-xs rounded-lg px-3 py-1.5 pr-7 focus:outline-none focus:ring-1 focus:ring-teal-500 cursor-pointer"
              >
                {COVERAGE_TYPES.map((c) => (
                  <option key={c}>{c}</option>
                ))}
              </select>
              <ChevronDown className="w-3 h-3 text-slate-400 absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>

            {/* Renewal window */}
            <div className="relative">
              <select
                value={renewalWindow}
                onChange={(e) => setRenewalWindow(e.target.value)}
                className="appearance-none bg-slate-700 border border-slate-600 text-slate-300 text-xs rounded-lg px-3 py-1.5 pr-7 focus:outline-none focus:ring-1 focus:ring-teal-500 cursor-pointer"
              >
                {RENEWAL_WINDOWS.map((r) => (
                  <option key={r}>{r}</option>
                ))}
              </select>
              <ChevronDown className="w-3 h-3 text-slate-400 absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* ── Power BI Report ── */}
        <section>
          <h2 className="section-header">Policies Report</h2>
          <PowerBIReport
            config={REPORTS.policies}
            height="700px"
            filterPaneVisible={true}
          />
        </section>
      </main>
    </>
  );
}
