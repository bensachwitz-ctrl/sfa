"use client";

import { useEffect, useState } from "react";
import TopBar from "@/components/TopBar";
import StatCard from "@/components/StatCard";
import PortfolioIncurredChart from "@/components/charts/PortfolioIncurredChart";
import LineOfBusinessChart from "@/components/charts/LineOfBusinessChart";
import ClaimsByCategoryChart from "@/components/charts/ClaimsByCategoryChart";
import {
  FileText,
  Shield,
  Building2,
  Activity,
  AlertCircle,
  DollarSign,
  TrendingUp,
  ChevronRight,
} from "lucide-react";
import Link from "next/link";

interface KPIs {
  totalClaims: number;
  openClaims: number;
  closedClaims: number;
  totalIncurred: number;
  totalPaid: number;
  totalReserved: number;
  totalCompanies: number;
  companiesWithOpenClaims: number;
  avgClaimsPerCompany: number;
  avgIncurredPerClaim: number;
}

interface PortfolioCharts {
  incurredByYear: Array<{ year: string; incurred: number; paid: number; reserved: number; claims: number }>;
  claimsByLine: Array<{ line: string; count: number; incurred: number }>;
  claimsByCarrier: Array<{ carrier: string; count: number; incurred: number }>;
  claimsByCategory: Array<{ category: string; count: number; incurred: number }>;
  topByIncurred: Array<{ name: string; incurred: number; openClaims: number; totalClaims: number }>;
}

function fmt(n: number) {
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(2)}M`;
  if (n >= 1_000) return `$${(n / 1_000).toFixed(0)}K`;
  return `$${Math.round(n)}`;
}

function ChartCard({
  title, subtitle, children, height = "240px",
}: {
  title: string; subtitle?: string; children: React.ReactNode; height?: string;
}) {
  return (
    <div className="card-padded">
      <div className="mb-4">
        <p className="text-slate-200 font-semibold text-sm">{title}</p>
        {subtitle && <p className="text-slate-500 text-xs mt-0.5">{subtitle}</p>}
      </div>
      <div style={{ height }}>{children}</div>
    </div>
  );
}

const CARRIER_COLORS: Record<string, string> = {
  Accredited: "bg-teal-500",
  FICoSE: "bg-violet-500",
  SFP: "bg-orange-500",
  Lloyds: "bg-blue-500",
};

export default function OverviewPage() {
  const [kpis, setKpis] = useState<KPIs | null>(null);
  const [charts, setCharts] = useState<PortfolioCharts | null>(null);

  useEffect(() => {
    fetch("/api/kpis").then((r) => r.json()).then(setKpis).catch(() => {});
    fetch("/api/portfolio-charts").then((r) => r.json()).then(setCharts).catch(() => {});
  }, []);

  const totalIncurredFmt = kpis ? fmt(kpis.totalIncurred) : "—";
  const totalReservedFmt = kpis ? fmt(kpis.totalReserved) : "—";

  return (
    <>
      <TopBar
        title="Agency Overview"
        subtitle="Swamp Fox Agency — 822 claims · 77 insureds · $42M total incurred"
      />

      <main className="page-body space-y-6">
        {/* ── KPI Row ────────────────────────────────────────────────────── */}
        <section>
          <h2 className="section-header flex items-center gap-2">
            <Activity className="w-4 h-4 text-teal-400" /> Portfolio Summary
          </h2>
          <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
            <StatCard
              label="Total Claims"
              value={kpis?.totalClaims ?? "—"}
              subtext="All carriers · all years"
              icon={FileText}
              variant="default"
              loading={!kpis}
            />
            <StatCard
              label="Open Claims"
              value={kpis?.openClaims ?? "—"}
              subtext={kpis ? `${kpis.companiesWithOpenClaims} companies affected` : "Awaiting resolution"}
              icon={AlertCircle}
              variant={kpis && kpis.openClaims > 50 ? "danger" : "warning"}
              loading={!kpis}
            />
            <StatCard
              label="Total Incurred"
              value={totalIncurredFmt}
              subtext="Paid + reserved (all time)"
              icon={DollarSign}
              variant="default"
              loading={!kpis}
            />
            <StatCard
              label="Open Reserves"
              value={totalReservedFmt}
              subtext="Active open claim reserves"
              icon={TrendingUp}
              variant={kpis && kpis.totalReserved > 1_000_000 ? "warning" : "default"}
              loading={!kpis}
            />
          </div>
        </section>

        {/* ── Second KPI Row ─────────────────────────────────────────────── */}
        <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
          <StatCard
            label="Insured Companies"
            value={kpis?.totalCompanies ?? "—"}
            subtext="Active insureds in portfolio"
            icon={Building2}
            variant="default"
            loading={!kpis}
          />
          <StatCard
            label="Avg Claims / Company"
            value={kpis?.avgClaimsPerCompany ?? "—"}
            subtext="Portfolio average"
            icon={FileText}
            variant="default"
            loading={!kpis}
          />
          <StatCard
            label="Closed Claims"
            value={kpis?.closedClaims ?? "—"}
            subtext="Successfully resolved"
            icon={Shield}
            variant="success"
            loading={!kpis}
          />
          <StatCard
            label="Avg Incurred / Claim"
            value={kpis ? fmt(kpis.avgIncurredPerClaim) : "—"}
            subtext="Across all claims"
            icon={DollarSign}
            variant="default"
            loading={!kpis}
          />
        </div>

        {/* ── Incurred / Paid / Reserved by Year ────────────────────────── */}
        <section>
          <h2 className="section-header flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-teal-400" /> Loss History by Year
          </h2>
          <ChartCard
            title="Paid vs. Reserved — Annual Portfolio Trend"
            subtitle="Paid losses (teal) · open reserves (amber) · claim count (dashed)"
            height="280px"
          >
            <PortfolioIncurredChart data={charts?.incurredByYear ?? []} />
          </ChartCard>
        </section>

        {/* ── Line of Business + Top Categories ─────────────────────────── */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <ChartCard
            title="Incurred by Line of Business"
            subtitle="AL · GL · APD — share of total incurred"
            height="240px"
          >
            <LineOfBusinessChart data={charts?.claimsByLine ?? []} mode="incurred" />
          </ChartCard>

          <ChartCard
            title="Top Loss Categories"
            subtitle="Total incurred by accident category"
            height="240px"
          >
            <ClaimsByCategoryChart
              data={charts?.claimsByCategory ?? []}
              mode="incurred"
            />
          </ChartCard>
        </div>

        {/* ── Carrier breakdown + Top Companies ─────────────────────────── */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Carrier card */}
          <div className="card-padded">
            <p className="text-slate-200 font-semibold text-sm mb-4">Claims by Carrier</p>
            <div className="space-y-3">
              {(charts?.claimsByCarrier ?? []).map((c) => {
                const total = (charts?.claimsByCarrier ?? []).reduce(
                  (s, x) => s + x.count, 0
                );
                const pct = total ? Math.round((c.count / total) * 100) : 0;
                return (
                  <div key={c.carrier} className="flex items-center gap-3">
                    <div
                      className={`w-2 h-2 rounded-full shrink-0 ${CARRIER_COLORS[c.carrier] ?? "bg-slate-500"}`}
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-slate-200 text-sm font-medium">{c.carrier}</span>
                        <span className="text-slate-400 text-xs">
                          {c.count} claims · {fmt(c.incurred)}
                        </span>
                      </div>
                      <div className="h-1.5 bg-slate-700 rounded-full">
                        <div
                          className={`h-1.5 rounded-full ${CARRIER_COLORS[c.carrier] ?? "bg-slate-500"}`}
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                    <span className="text-slate-500 text-xs w-8 text-right">{pct}%</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Top 10 companies by incurred */}
          <div className="card-padded">
            <div className="flex items-center justify-between mb-4">
              <p className="text-slate-200 font-semibold text-sm">Top 10 by Total Incurred</p>
              <Link
                href="/companies"
                className="text-teal-400 text-xs hover:text-teal-300 flex items-center gap-1"
              >
                All companies <ChevronRight className="w-3 h-3" />
              </Link>
            </div>
            <div className="space-y-2">
              {(charts?.topByIncurred ?? []).map((c, i) => {
                const max =
                  charts?.topByIncurred[0]?.incurred ?? 1;
                const pct = Math.round((c.incurred / max) * 100);
                return (
                  <div key={c.name} className="group">
                    <Link href={`/companies/${encodeURIComponent(c.name)}`}>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-slate-500 text-xs w-4">{i + 1}</span>
                        <span className="text-slate-200 text-xs font-medium truncate flex-1 group-hover:text-teal-300 transition-colors">
                          {c.name}
                        </span>
                        <span className="text-slate-300 text-xs font-semibold shrink-0">
                          {fmt(c.incurred)}
                        </span>
                        {c.openClaims > 0 && (
                          <span className="text-[10px] bg-red-900/40 text-red-400 border border-red-700/40 px-1.5 py-0.5 rounded-full shrink-0">
                            {c.openClaims} open
                          </span>
                        )}
                      </div>
                      <div className="h-1 bg-slate-700 rounded-full ml-6">
                        <div
                          className="h-1 rounded-full bg-orange-500/70"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </Link>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* ── Quick Nav ──────────────────────────────────────────────────── */}
        <section>
          <h2 className="section-header">Quick Navigation</h2>
          <div className="grid grid-cols-2 xl:grid-cols-4 gap-3">
            {[
              {
                href: "/claims",
                label: "Claims",
                description: "Browse all 822 claims by company",
                icon: FileText,
                color: "text-teal-400",
                bg: "bg-teal-900/30 border-teal-700/30",
              },
              {
                href: "/companies",
                label: "Companies",
                description: "77 insureds with SAFER + loss data",
                icon: Building2,
                color: "text-amber-400",
                bg: "bg-amber-900/30 border-amber-700/30",
              },
              {
                href: "/risk-alerts",
                label: "Risk Alerts",
                description: "Open claims, OOS rates, SAFER flags",
                icon: AlertCircle,
                color: "text-red-400",
                bg: "bg-red-900/30 border-red-700/30",
              },
              {
                href: "/drivers",
                label: "Drivers",
                description: "Telematics & risk scores (via Samsara)",
                icon: Shield,
                color: "text-purple-400",
                bg: "bg-purple-900/30 border-purple-700/30",
              },
            ].map(({ href, label, description, icon: Icon, color, bg }) => (
              <Link
                key={href}
                href={href}
                className={`card-padded border ${bg} hover:brightness-110 transition-all group`}
              >
                <Icon className={`w-6 h-6 ${color} mb-3`} />
                <p className="text-slate-200 font-semibold text-sm group-hover:text-white transition-colors">
                  {label}
                </p>
                <p className="text-slate-500 text-xs mt-1">{description}</p>
              </Link>
            ))}
          </div>
        </section>
      </main>
    </>
  );
}
