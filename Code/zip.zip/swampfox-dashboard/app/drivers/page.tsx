"use client";

import { useState } from "react";
import TopBar from "@/components/TopBar";
import PowerBIReport from "@/components/PowerBIReport";
import StatCard from "@/components/StatCard";
import RiskBadge from "@/components/RiskBadge";
import { REPORTS } from "@/lib/powerbiConfig";
import {
  Users,
  Gauge,
  Zap,
  AlertOctagon,
  Search,
  ChevronDown,
  Activity,
} from "lucide-react";
import clsx from "clsx";

const RISK_FILTERS = ["All", "High Risk", "Medium Risk", "Low Risk"];
const EVENT_TYPES = [
  "All Events",
  "Speeding",
  "Hard Braking",
  "Harsh Acceleration",
  "Harsh Cornering",
  "Phone Use",
];
const DATE_RANGES = ["Last 7 Days", "Last 30 Days", "Last 90 Days", "YTD"];

// Placeholder rows — real data comes from Power BI / Fabric
const SAMPLE_DRIVERS = [
  { id: "D-001", name: "—", violations: "—", speed: "—", braking: "—", score: "—", risk: "high" as const },
  { id: "D-002", name: "—", violations: "—", speed: "—", braking: "—", score: "—", risk: "medium" as const },
  { id: "D-003", name: "—", violations: "—", speed: "—", braking: "—", score: "—", risk: "low" as const },
];

export default function DriversPage() {
  const [riskFilter, setRiskFilter] = useState("All");
  const [eventType, setEventType] = useState("All Events");
  const [dateRange, setDateRange] = useState("Last 30 Days");
  const [search, setSearch] = useState("");

  return (
    <>
      <TopBar
        title="Driver Risk & Telematics"
        subtitle="Safety scores, Samsara speed events, and driver risk profiles"
      />

      <main className="page-body space-y-6">
        {/* ── KPIs ── */}
        <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
          <StatCard
            label="Total Drivers"
            value="—"
            subtext="Across all insured companies"
            icon={Users}
            variant="default"
          />
          <StatCard
            label="High-Risk Drivers"
            value="—"
            subtext="Above risk threshold"
            icon={AlertOctagon}
            variant="danger"
            trend="up"
            trendValue="Flag"
          />
          <StatCard
            label="Speeding Events (30d)"
            value="—"
            subtext="Samsara telematics — all fleets"
            icon={Gauge}
            variant="warning"
          />
          <StatCard
            label="Harsh Braking Events"
            value="—"
            subtext="30-day rolling window"
            icon={Zap}
            variant="warning"
          />
        </div>

        {/* ── Filters ── */}
        <div className="card-padded">
          <div className="flex flex-wrap items-center gap-4">
            {/* Search */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                placeholder="Search driver..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="bg-slate-700 border border-slate-600 text-slate-300 text-xs rounded-lg pl-8 pr-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-teal-500 w-40"
              />
            </div>

            <div className="h-4 w-px bg-slate-700 hidden sm:block" />

            {/* Risk level pills */}
            <div className="flex items-center gap-1.5 flex-wrap">
              {RISK_FILTERS.map((r) => (
                <button
                  key={r}
                  onClick={() => setRiskFilter(r)}
                  className={clsx(
                    "px-3 py-1 rounded-full text-xs font-medium transition-colors",
                    riskFilter === r
                      ? "bg-teal-600 text-white"
                      : "bg-slate-700 text-slate-400 hover:bg-slate-600 hover:text-slate-200"
                  )}
                >
                  {r}
                </button>
              ))}
            </div>

            <div className="h-4 w-px bg-slate-700 hidden sm:block" />

            {/* Event type */}
            <div className="relative">
              <select
                value={eventType}
                onChange={(e) => setEventType(e.target.value)}
                className="appearance-none bg-slate-700 border border-slate-600 text-slate-300 text-xs rounded-lg px-3 py-1.5 pr-7 focus:outline-none focus:ring-1 focus:ring-teal-500 cursor-pointer"
              >
                {EVENT_TYPES.map((e) => <option key={e}>{e}</option>)}
              </select>
              <ChevronDown className="w-3 h-3 text-slate-400 absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>

            {/* Date range */}
            <div className="relative">
              <select
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value)}
                className="appearance-none bg-slate-700 border border-slate-600 text-slate-300 text-xs rounded-lg px-3 py-1.5 pr-7 focus:outline-none focus:ring-1 focus:ring-teal-500 cursor-pointer"
              >
                {DATE_RANGES.map((d) => <option key={d}>{d}</option>)}
              </select>
              <ChevronDown className="w-3 h-3 text-slate-400 absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* ── Driver Table (preview — real data in PBI embed) ── */}
        <section>
          <h2 className="section-header flex items-center gap-2">
            <Activity className="w-4 h-4 text-teal-400" />
            Driver Summary
            <span className="text-slate-500 text-xs font-normal">(Full data in report below)</span>
          </h2>
          <div className="card overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-700/60">
                  <th className="text-left text-slate-400 text-xs font-medium px-4 py-3">Driver ID</th>
                  <th className="text-left text-slate-400 text-xs font-medium px-4 py-3">Name</th>
                  <th className="text-left text-slate-400 text-xs font-medium px-4 py-3">Violations</th>
                  <th className="text-left text-slate-400 text-xs font-medium px-4 py-3">Speed Events</th>
                  <th className="text-left text-slate-400 text-xs font-medium px-4 py-3">Hard Braking</th>
                  <th className="text-left text-slate-400 text-xs font-medium px-4 py-3">Safety Score</th>
                  <th className="text-left text-slate-400 text-xs font-medium px-4 py-3">Risk Level</th>
                </tr>
              </thead>
              <tbody>
                {SAMPLE_DRIVERS.map((driver, i) => (
                  <tr
                    key={driver.id}
                    className={clsx(
                      "border-b border-slate-700/30 hover:bg-slate-800/40 transition-colors",
                      i === SAMPLE_DRIVERS.length - 1 && "border-0"
                    )}
                  >
                    <td className="px-4 py-3 text-slate-400 font-mono text-xs">{driver.id}</td>
                    <td className="px-4 py-3 text-slate-300">{driver.name}</td>
                    <td className="px-4 py-3 text-slate-400">{driver.violations}</td>
                    <td className="px-4 py-3 text-slate-400">{driver.speed}</td>
                    <td className="px-4 py-3 text-slate-400">{driver.braking}</td>
                    <td className="px-4 py-3 text-slate-300 font-medium">{driver.score}</td>
                    <td className="px-4 py-3">
                      <RiskBadge level={driver.risk} pulse />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <p className="text-slate-600 text-xs px-4 py-3 border-t border-slate-700/30">
              Sample structure — connect Microsoft Fabric Lakehouse to populate real driver data
            </p>
          </div>
        </section>

        {/* ── Power BI / Samsara Report ── */}
        <section>
          <h2 className="section-header">
            Driver Risk & Telematics Report
            <span className="ml-2 text-xs font-normal text-teal-500 border border-teal-700/50 bg-teal-900/20 px-2 py-0.5 rounded-full">
              Samsara Data
            </span>
          </h2>
          <PowerBIReport
            config={REPORTS.drivers}
            height="720px"
            filterPaneVisible={true}
          />
        </section>
      </main>
    </>
  );
}
