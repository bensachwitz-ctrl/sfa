"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import TopBar from "@/components/TopBar";
import StatCard from "@/components/StatCard";
import {
  AlertTriangle, Users, Shield, Bell, Building2,
  ChevronRight, ArrowRight, Truck, Loader2,
  AlertCircle, DollarSign, ShieldAlert,
} from "lucide-react";
import Link from "next/link";
import clsx from "clsx";

interface RiskAlert {
  id: string;
  type: "open_claims" | "high_incurred" | "safer" | "oos_rate";
  severity: "high" | "medium" | "low";
  companyName: string;
  companyId: string;
  title: string;
  detail: string;
}

interface AlertStats {
  total: number;
  high: number;
  medium: number;
  companiesAffected: number;
}

function fmt(n: number) {
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `$${(n / 1_000).toFixed(0)}K`;
  return `$${Math.round(n)}`;
}

const SEVERITY_STYLES: Record<string, string> = {
  high: "border-l-red-500",
  medium: "border-l-amber-500",
  low: "border-l-slate-600",
};

const SEVERITY_BADGE: Record<string, string> = {
  high: "text-red-400 bg-red-900/30 border-red-700/40",
  medium: "text-amber-400 bg-amber-900/30 border-amber-700/40",
  low: "text-slate-400 bg-slate-700/40 border-slate-600/40",
};

const TYPE_ICONS: Record<string, React.ElementType> = {
  open_claims: AlertCircle,
  high_incurred: DollarSign,
  safer: Shield,
  oos_rate: Truck,
};

const TYPE_LABEL: Record<string, string> = {
  open_claims: "Open Claims",
  high_incurred: "High Losses",
  safer: "SAFER Rating",
  oos_rate: "OOS Rate",
};

export default function RiskAlertsPage() {
  const router = useRouter();
  const [alerts, setAlerts] = useState<RiskAlert[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [filterType, setFilterType] = useState<string>("All");
  const [filterSeverity, setFilterSeverity] = useState<string>("All");

  useEffect(() => {
    fetch("/api/risk-alerts")
      .then((r) => r.json())
      .then((d) => { setAlerts(d.alerts ?? d); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const filtered = (alerts ?? []).filter((a) => {
    if (filterType !== "All" && a.type !== filterType) return false;
    if (filterSeverity !== "All" && a.severity !== filterSeverity) return false;
    return true;
  });

  const stats: AlertStats = alerts
    ? {
        total: alerts.length,
        high: alerts.filter((a) => a.severity === "high").length,
        medium: alerts.filter((a) => a.severity === "medium").length,
        companiesAffected: new Set(alerts.map((a) => a.companyId)).size,
      }
    : { total: 0, high: 0, medium: 0, companiesAffected: 0 };

  return (
    <>
      <TopBar
        title="Risk Alerts"
        subtitle="Open claims · high incurred · SAFER flags · OOS rate issues"
      />

      <main className="page-body space-y-6">
        {/* ── KPIs ────────────────────────────────────────────────────────── */}
        <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
          <StatCard
            label="Total Alerts"
            value={alerts?.length ?? "—"}
            subtext="Requiring attention"
            icon={Bell}
            variant="danger"
            loading={loading}
          />
          <StatCard
            label="High-Severity"
            value={stats.high || "—"}
            subtext="Immediate action needed"
            icon={ShieldAlert}
            variant="danger"
            loading={loading}
          />
          <StatCard
            label="Medium-Severity"
            value={stats.medium || "—"}
            subtext="Review within 5 days"
            icon={AlertTriangle}
            variant="warning"
            loading={loading}
          />
          <StatCard
            label="Companies Affected"
            value={stats.companiesAffected || "—"}
            subtext="With one or more alerts"
            icon={Building2}
            variant={stats.companiesAffected > 10 ? "warning" : "default"}
            loading={loading}
          />
        </div>

        {/* ── Filters ─────────────────────────────────────────────────────── */}
        <div className="card-padded">
          <div className="flex flex-wrap items-center gap-3">
            <span className="text-slate-500 text-xs font-medium">Severity:</span>
            {["All", "high", "medium"].map((s) => (
              <button
                key={s}
                onClick={() => setFilterSeverity(s)}
                className={clsx(
                  "px-3 py-1 rounded-full text-xs font-medium transition-colors capitalize",
                  filterSeverity === s
                    ? "bg-teal-600 text-white"
                    : "bg-slate-700 text-slate-400 hover:bg-slate-600"
                )}
              >
                {s}
              </button>
            ))}
            <div className="h-4 w-px bg-slate-700 hidden sm:block" />
            <span className="text-slate-500 text-xs font-medium">Type:</span>
            {["All", "open_claims", "high_incurred", "safer", "oos_rate"].map((t) => (
              <button
                key={t}
                onClick={() => setFilterType(t)}
                className={clsx(
                  "px-3 py-1 rounded-full text-xs font-medium transition-colors",
                  filterType === t
                    ? "bg-teal-600 text-white"
                    : "bg-slate-700 text-slate-400 hover:bg-slate-600"
                )}
              >
                {t === "All" ? "All" : TYPE_LABEL[t]}
              </button>
            ))}
            <span className="text-slate-600 text-xs ml-auto hidden lg:block">
              {filtered.length} of {alerts?.length ?? 0} alerts
            </span>
          </div>
        </div>

        {/* ── Alert Feed ──────────────────────────────────────────────────── */}
        {loading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="w-7 h-7 animate-spin text-teal-400" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="card-padded text-center text-slate-500 py-10">
            No alerts match the current filters.
          </div>
        ) : (
          <section>
            <div className="space-y-2">
              {filtered.map((alert) => {
                const Icon = TYPE_ICONS[alert.type] ?? AlertTriangle;
                return (
                  <div
                    key={alert.id}
                    className={clsx(
                      "card-padded flex items-center gap-4 border-l-4 hover:bg-slate-700/20 transition-colors cursor-pointer",
                      SEVERITY_STYLES[alert.severity]
                    )}
                    onClick={() =>
                      router.push(
                        `/companies/${encodeURIComponent(alert.companyId)}`
                      )
                    }
                  >
                    <div className="w-9 h-9 rounded-full bg-slate-700/60 flex items-center justify-center shrink-0">
                      <Icon className="w-4 h-4 text-slate-300" />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-0.5">
                        <p className="text-slate-200 font-semibold text-sm">
                          {alert.companyName}
                        </p>
                        <span
                          className={clsx(
                            "text-[10px] px-2 py-0.5 rounded-full border font-medium",
                            SEVERITY_BADGE[alert.severity]
                          )}
                        >
                          {alert.severity}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-700/50 text-slate-400 border border-slate-600/40">
                          {TYPE_LABEL[alert.type]}
                        </span>
                      </div>
                      <p className="text-teal-300 text-xs font-medium">{alert.title}</p>
                      <p className="text-slate-400 text-xs mt-0.5">{alert.detail}</p>
                    </div>

                    <ChevronRight className="w-4 h-4 text-slate-600 group-hover:text-teal-400 transition-colors shrink-0" />
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {/* ── Quick Actions ────────────────────────────────────────────────── */}
        <section>
          <h2 className="section-header">Quick Actions</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <Link
              href="/claims?status=Open"
              className="card-padded flex items-center justify-between hover:bg-slate-700/40 transition-colors group"
            >
              <div className="flex items-center gap-3">
                <AlertCircle className="w-5 h-5 text-red-400" />
                <div>
                  <p className="text-slate-200 text-sm font-medium">
                    Review Open Claims
                  </p>
                  <p className="text-slate-500 text-xs">
                    115 open claims across portfolio
                  </p>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-teal-400 transition-colors" />
            </Link>
            <Link
              href="/companies"
              className="card-padded flex items-center justify-between hover:bg-slate-700/40 transition-colors group"
            >
              <div className="flex items-center gap-3">
                <Building2 className="w-5 h-5 text-amber-400" />
                <div>
                  <p className="text-slate-200 text-sm font-medium">
                    Company Risk Review
                  </p>
                  <p className="text-slate-500 text-xs">
                    Sort by risk score
                  </p>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-teal-400 transition-colors" />
            </Link>
            <Link
              href="/drivers"
              className="card-padded flex items-center justify-between hover:bg-slate-700/40 transition-colors group"
            >
              <div className="flex items-center gap-3">
                <Users className="w-5 h-5 text-purple-400" />
                <div>
                  <p className="text-slate-200 text-sm font-medium">
                    Driver Risk & Telematics
                  </p>
                  <p className="text-slate-500 text-xs">
                    Connect Samsara for live data
                  </p>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-teal-400 transition-colors" />
            </Link>
          </div>
        </section>

        {/* ── Alert legend ─────────────────────────────────────────────────── */}
        <div className="card-padded bg-slate-800/30">
          <p className="text-slate-500 text-xs font-medium uppercase tracking-wider mb-3">
            Alert Definitions
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-400">
            <div className="flex gap-2">
              <AlertCircle className="w-3.5 h-3.5 text-red-400 shrink-0 mt-0.5" />
              <span><strong className="text-slate-300">Open Claims:</strong> 4+ open = High · 2-3 open = Medium</span>
            </div>
            <div className="flex gap-2">
              <DollarSign className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
              <span><strong className="text-slate-300">High Losses:</strong> $2M+ incurred = High · $1M+ = Medium</span>
            </div>
            <div className="flex gap-2">
              <Shield className="w-3.5 h-3.5 text-blue-400 shrink-0 mt-0.5" />
              <span><strong className="text-slate-300">SAFER Rating:</strong> Conditional or Unsatisfactory rating on file</span>
            </div>
            <div className="flex gap-2">
              <Truck className="w-3.5 h-3.5 text-orange-400 shrink-0 mt-0.5" />
              <span><strong className="text-slate-300">OOS Rate:</strong> Vehicle out-of-service rate &gt; 20%</span>
            </div>
          </div>
        </div>
      </main>
    </>
  );
}
