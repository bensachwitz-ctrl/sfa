import { NextRequest, NextResponse } from "next/server";
import { getMasterClaims, type MasterClaim } from "@/lib/masterData";

export async function GET(req: NextRequest) {
  const { searchParams } = req.nextUrl;
  const q = searchParams.get("q")?.toLowerCase() ?? "";
  const status = searchParams.get("status") ?? "All";
  const line = searchParams.get("line") ?? "All";
  const carrier = searchParams.get("carrier") ?? "All";
  const category = searchParams.get("category") ?? "All";
  const state = searchParams.get("state") ?? "All";
  const company = searchParams.get("company") ?? "";
  const page = Math.max(1, parseInt(searchParams.get("page") ?? "1"));
  const pageSize = 50;

  let claims: MasterClaim[] = getMasterClaims();

  // Filter by selected company (for use with CompanySearchContext)
  if (company) {
    const codes = company.split(",").map((c) => c.trim());
    claims = claims.filter((c) => codes.includes(c.insured));
  }

  if (status !== "All") claims = claims.filter((c) => c.status === status);
  if (line !== "All") claims = claims.filter((c) => c.line === line);
  if (carrier !== "All") claims = claims.filter((c) => c.carrier === carrier);
  if (category !== "All") claims = claims.filter((c) => c.category === category);
  if (state !== "All") claims = claims.filter((c) => c.state === state);
  if (q) {
    claims = claims.filter(
      (c) =>
        c.claimNumber.toLowerCase().includes(q) ||
        c.insured.toLowerCase().includes(q) ||
        c.policyNumber.toLowerCase().includes(q) ||
        c.driver.toLowerCase().includes(q) ||
        c.accidentDesc.toLowerCase().includes(q)
    );
  }

  // Sort: open first, then by date descending
  claims = claims.sort((a, b) => {
    if (a.status !== b.status)
      return a.status === "Open" ? -1 : 1;
    return b.dateOfLoss.localeCompare(a.dateOfLoss);
  });

  const total = claims.length;
  const totalPages = Math.ceil(total / pageSize);
  const paginated = claims.slice((page - 1) * pageSize, page * pageSize);

  // Summary stats for the current filtered set
  const totalIncurred = claims.reduce((s, c) => s + c.totalIncurred, 0);
  const totalPaid = claims.reduce((s, c) => s + c.totalPaid, 0);
  const totalReserved = claims.reduce((s, c) => s + c.totalReserve, 0);
  const openCount = claims.filter((c) => c.status === "Open").length;

  return NextResponse.json({
    claims: paginated,
    pagination: { page, pageSize, total, totalPages },
    summary: { totalIncurred, totalPaid, totalReserved, openCount, closedCount: total - openCount },
  });
}
