import { NextResponse } from "next/server";
import { isFabricConfigured, getFabricConfig, SQL } from "@/lib/fabricDb";
import { getMasterPortfolioKPIs } from "@/lib/masterData";

export async function GET() {
  if (isFabricConfigured()) {
    try {
      const sql = await import("mssql");
      const pool = await sql.connect(getFabricConfig());
      const result = await pool.request().query(SQL.kpis);
      await pool.close();
      return NextResponse.json(result.recordset[0]);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      console.error("[Fabric] KPI error:", msg);
    }
  }

  return NextResponse.json(getMasterPortfolioKPIs());
}
