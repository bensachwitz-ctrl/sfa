import { NextResponse } from "next/server";
import { isFabricConfigured, getFabricConfig, SQL } from "@/lib/fabricDb";
import {
  getMasterCompanies,
  type CompanySummary,
} from "@/lib/masterData";
import type { Company } from "@/lib/mockData";

// Map CompanySummary → Company so the existing UI context/search components
// continue to work without change. Premium/policy fields are left undefined
// until Fabric is connected.
function toCompany(s: CompanySummary): Company {
  return {
    id: s.id,
    accountName: s.name,
    accountCode: s.id,
    dotNumber: s.dot || undefined,
    city: s.address ? s.address.split(",")[0]?.trim() : undefined,
    state: s.states[0] || undefined,
    address: s.address || undefined,
    operatingStatus: s.operatingStatus,
    totalPaidLosses: s.totalPaid,
    openClaims: s.openClaims,
    totalIncurred: s.totalIncurred,
    totalReserved: s.totalReserved,
    totalClaims: s.totalClaims,
    topCategory: s.topCategory,
    topLine: s.topLine,
    carriers: s.carriers,
    states: s.states,
    riskScore: s.riskScore,
    lastLossDate: s.lastLossDate,
    firstLossDate: s.firstLossDate,
    vehicleInspections: s.vehicleInspections,
    vehicleOOSRate: s.vehicleOOSRate,
    driverInspections: s.driverInspections,
    driverOOSRate: s.driverOOSRate,
    saferRating: s.saferRating,
  };
}

export async function GET() {
  // ── Fabric path ────────────────────────────────────────────────────────────
  if (isFabricConfigured()) {
    try {
      const sql = await import("mssql");
      const pool = await sql.connect(getFabricConfig());
      const result = await pool.request().query(SQL.listCompanies);
      await pool.close();
      return NextResponse.json(result.recordset);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      console.error("[Fabric] companies list error:", msg);
      // fall through to master data
    }
  }

  // ── Master data path (JSON) ────────────────────────────────────────────────
  return NextResponse.json(getMasterCompanies().map(toCompany));
}
