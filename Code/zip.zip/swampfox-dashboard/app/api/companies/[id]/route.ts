import { NextRequest, NextResponse } from "next/server";
import { isFabricConfigured, getFabricConfig, SQL } from "@/lib/fabricDb";
import {
  getMasterCompanyByName,
  type CompanyDetail,
} from "@/lib/masterData";

// ── Response shape ─────────────────────────────────────────────────────────────
// `masterData` is populated from the JSON file now.
// `policies`, `drivers`, and Samsara charts arrive from Fabric later.
// UI components check for null/empty gracefully.

function buildResponse(detail: CompanyDetail | null, id: string) {
  if (!detail) {
    return NextResponse.json(
      { error: `Company not found: ${id}` },
      { status: 404 }
    );
  }

  return NextResponse.json({
    // Core company fields (shape compatible with existing Company interface)
    company: {
      id: detail.id,
      accountName: detail.name,
      accountCode: detail.id,
      dotNumber: detail.dot || null,
      address: detail.address,
      saferRating: detail.saferRating,
      operatingStatus: detail.operatingStatus,
      vehicleInspections: detail.vehicleInspections,
      vehicleOOSRate: detail.vehicleOOSRate,
      driverInspections: detail.driverInspections,
      driverOOSRate: detail.driverOOSRate,
      openClaims: detail.openClaims,
      totalIncurred: detail.totalIncurred,
      totalPaid: detail.totalPaid,
      totalReserved: detail.totalReserved,
      totalClaims: detail.totalClaims,
      topCategory: detail.topCategory,
      topLine: detail.topLine,
      carriers: detail.carriers,
      states: detail.states,
      riskScore: detail.riskScore,
      lastLossDate: detail.lastLossDate,
      firstLossDate: detail.firstLossDate,
    },
    // Claim history (from master JSON)
    claims: detail.claims,
    // Chart aggregations (pre-computed server-side)
    charts: {
      claimsByYear: detail.claimsByYear,
      claimsByCategory: detail.claimsByCategory,
      claimsByLine: detail.claimsByLine,
    },
    // Fabric data — empty until lakehouse is connected
    policies: [],
    drivers: [],
  });
}

export async function GET(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  const id = decodeURIComponent(params.id);

  // ── Fabric path ────────────────────────────────────────────────────────────
  if (isFabricConfigured()) {
    try {
      const sql = await import("mssql");
      const pool = await sql.connect(getFabricConfig());

      const [policies, claims, drivers] = await Promise.all([
        pool.request().query(SQL.policiesByCompany(id)),
        pool.request().query(SQL.claimsByCompany(id)),
        pool.request().query(SQL.driversByCompany(id)),
      ]);
      await pool.close();

      // When Fabric is connected, return Fabric data.
      // Still supplement with master data charts where possible.
      const detail = getMasterCompanyByName(id);
      return NextResponse.json({
        company: detail
          ? {
              id: detail.id,
              accountName: detail.name,
              accountCode: detail.id,
              dotNumber: detail.dot,
              address: detail.address,
              saferRating: detail.saferRating,
              operatingStatus: detail.operatingStatus,
              vehicleInspections: detail.vehicleInspections,
              vehicleOOSRate: detail.vehicleOOSRate,
              openClaims: detail.openClaims,
              totalIncurred: detail.totalIncurred,
              totalClaims: detail.totalClaims,
              riskScore: detail.riskScore,
            }
          : null,
        claims: claims.recordset,
        policies: policies.recordset,
        drivers: drivers.recordset,
        charts: {
          claimsByYear: detail?.claimsByYear ?? [],
          claimsByCategory: detail?.claimsByCategory ?? [],
          claimsByLine: detail?.claimsByLine ?? [],
        },
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      console.error("[Fabric] company detail error:", msg);
      // fall through
    }
  }

  // ── Master data path ───────────────────────────────────────────────────────
  const detail = getMasterCompanyByName(id);
  return buildResponse(detail, id);
}
