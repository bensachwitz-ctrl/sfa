import { NextResponse } from "next/server";
import { getMasterPortfolioCharts } from "@/lib/masterData";

export async function GET() {
  return NextResponse.json(getMasterPortfolioCharts());
}
