"use client";

import { useEffect, useState, useCallback } from "react";
import TopBar from "@/components/TopBar";
import StatCard from "@/components/StatCard";
import { useCompanySearch } from "@/contexts/CompanySearchContext";
import {
  FileText, Search, ChevronDown, ChevronRight, Loader2,
  DollarSign, AlertCircle, CheckCircle2, Building2,
  Filter, X,
} from "lucide-react";
import clsx from "clsx";

interface MasterClaim {
  carrier: string;
  insured: string;
  policyNumber: string;
  policyYear: number;
  claimNumber: string;
  dateOfLoss: string;
  status: "Open" | "Closed";
  claimType: string;
  line: "AL" | "GL" | "APD";
  causeOfLoss: string;
  category: string;
  totalPaid: number;
  totalReserve: number;
  totalIncurred: number;
  accidentDesc: string;
  driver: string;
  claimant: string;
  state: string;
  closeDate: string;
}

interface ClaimResponse {
  claims: MasterClaim[];
  pagination: { page: number; pageSize: number; total: number; totalPages: number };
  summary: { totalIncurred: number; totalPaid: number; totalReserved: number; openCount: number; closedCount: number };
}

interface CompanyGroup {
  name: string;
  claims: MasterClaim[];
  totalIncurred: number;
  totalPaid: number;
  totalReserved: number;
  openCount: number;
}

function fmt(n: number) {
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(2)}M`;
  if (n >= 1_000) return `$${(n / 1_000).toFixed(0)}K`;
  return `$${Math.round(n)}`;
}

const STATUS_COLORS: Record<string, string> = {
  Open: "text-red-400 bg-red-900/30 border-red-700/40",
  Closed: "text-slate-400 bg-slate-700/40 border-slate-600/40",
};

const LINE_COLORS: Record<string, string> = {
  AL: "text-teal-400 bg-teal-900/30 border-teal-700/40",
  GL: "text-purple-400 bg-purple-900/30 border-purple-700/40",
  APD: "text-orange-400 bg-orange-900/30 border-orange-700/40",
};

export default function ClaimsPage() {
  const { selectedAccountCodes } = useCompanySearch();

  const [data, setData] = useState<ClaimResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("All");
  const [line, setLine] = useState("All");
  const [carrier, setCarrier] = useState("All");
  const [page, setPage] = useState(1);
  const [expandedCompanies, setExpandedCompanies] = useState<Set<string>>(new Set());

  const buildUrl = useCallback(() => {
    const p = new URLSearchParams();
    if (search) p.set("q", search);
    if (status !== "All") p.set("status", status);
    if (line !== "All") p.set("line", line);
    if (carrier !== "All") p.set("carrier", carrier);
    if (selectedAccountCodes.length > 0) p.set("company", selectedAccountCodes.join(","));
    p.set("page", String(page));
    return `/api/claims?${p.toString()}`;
  }, [search, status, line, carrier, selectedAccountCodes, page]);

  useEffect(() => {
    setLoading(true);
    fetch(buildUrl())
      .then((r) => r.json())
      .then((d) => { setData(d); setLoading(false); })
      .catch(() => setLoading(false));
  }, [buildUrl]);

  // Reset page when filters change
  useEffect(() => { setPage(1); }, [search, status, line, carrier, selectedAccountCodes]);

  // Group claims by company
  const grouped: CompanyGroup[] = [];
  if (data?.claims) {
    const map = new Map<string, MasterClaim[]>();
    for (const c of data.claims) {
      if (!map.has(c.insured)) map.set(c.insured, []);
      map.get(c.insured)!.push(c);
    }
    for (const [name, claims] of map) {
      grouped.push({
        name,
        claims,
        totalIncurred: claims.reduce((s, c) => s + c.totalIncurred, 0),
        totalPaid: claims.reduce((s, c) => s + c.totalPaid, 0),
        totalReserved: claims.reduce((s, c) => s + c.totalReserve, 0),
        openCount: claims.filter((c) => c.status === "Open").length,
      });
    }
    grouped.sort((a, b) => b.openCount - a.openCount || b.totalIncurred - a.totalIncurred);
  }

  function toggleCompany(name: string) {
    setExpandedCompanies((prev) => {
      const next = new Set(prev);
      if (next.has(name)) next.delete(name);
      else next.add(name);
      return next;
    });
  }

  const hasFilters =
    search || status !== "All" || line !== "All" || carrier !== "All";

  return (
    <>
      <TopBar
        title="Claims"
        subtitle="All 822 claims · grouped by insured company"
      />

      <main className="page-body space-y-5">
        {/* ── KPI Row ─────────────────────────────────────────────────────── */}
        <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
          <StatCard
            label="Filtered Claims"
            value={data?.pagination.total ?? "—"}
            subtext="Matching current filters"
            icon={FileText}
            variant="default"
            loading={loading}
          />
          <StatCard
            label="Open Claims"
            value={data?.summary.openCount ?? "—"}
            subtext="Require action"
            icon={AlertCircle}
            variant="warning"
            loading={loading}
          />
          <StatCard
            label="Total Incurred"
            value={data ? fmt(data.summary.totalIncurred) : "—"}
            subtext="Paid + reserved"
            icon={DollarSign}
            variant="default"
            loading={loading}
          />
          <StatCard
            label="Open Reserves"
            value={data ? fmt(data.summary.totalReserved) : "—"}
            subtext="Active claim reserves"
            icon={CheckCircle2}
            variant={data && data.summary.totalReserved > 500_000 ? "warning" : "default"}
            loading={loading}
          />
        </div>

        {/* ── Filters ─────────────────────────────────────────────────────── */}
        <div className="card-padded">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1.5 text-slate-400 text-sm font-medium shrink-0">
              <Filter className="w-4 h-4" />
            </div>

            {/* Search */}
            <div className="relative min-w-[200px] flex-1 max-w-xs">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                placeholder="Claim #, company, driver…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full bg-slate-700 border border-slate-600 text-slate-200 text-xs rounded-xl pl-9 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-teal-500/60"
              />
            </div>

            <div className="h-4 w-px bg-slate-700 hidden sm:block" />

            {/* Status pills */}
            <div className="flex items-center gap-1.5 flex-wrap">
              {["All", "Open", "Closed"].map((s) => (
                <button
                  key={s}
                  onClick={() => setStatus(s)}
                  className={clsx(
                    "px-3 py-1 rounded-full text-xs font-medium transition-colors",
                    status === s
                      ? "bg-teal-600 text-white"
                      : "bg-slate-700 text-slate-400 hover:bg-slate-600"
                  )}
                >
                  {s}
                </button>
              ))}
            </div>

            <div className="h-4 w-px bg-slate-700 hidden sm:block" />

            {/* Line dropdown */}
            <div className="relative">
              <select
                value={line}
                onChange={(e) => setLine(e.target.value)}
                className="appearance-none bg-slate-700 border border-slate-600 text-slate-300 text-xs rounded-lg px-3 py-1.5 pr-7 focus:outline-none focus:ring-1 focus:ring-teal-500 cursor-pointer"
              >
                <option value="All">All Lines</option>
                <option value="AL">Auto Liability</option>
                <option value="GL">General Liability</option>
                <option value="APD">Auto Physical Damage</option>
              </select>
              <ChevronDown className="w-3 h-3 text-slate-400 absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>

            {/* Carrier dropdown */}
            <div className="relative">
              <select
                value={carrier}
                onChange={(e) => setCarrier(e.target.value)}
                className="appearance-none bg-slate-700 border border-slate-600 text-slate-300 text-xs rounded-lg px-3 py-1.5 pr-7 focus:outline-none focus:ring-1 focus:ring-teal-500 cursor-pointer"
              >
                <option value="All">All Carriers</option>
                <option value="Accredited">Accredited</option>
                <option value="FICoSE">FICoSE</option>
                <option value="SFP">SFP</option>
                <option value="Lloyds">Lloyds</option>
              </select>
              <ChevronDown className="w-3 h-3 text-slate-400 absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>

            {hasFilters && (
              <button
                onClick={() => {
                  setSearch("");
                  setStatus("All");
                  setLine("All");
                  setCarrier("All");
                }}
                className="flex items-center gap-1 text-slate-500 hover:text-red-400 text-xs transition-colors"
              >
                <X className="w-3 h-3" /> Clear
              </button>
            )}

            <span className="text-slate-600 text-xs ml-auto hidden lg:block">
              {data?.pagination.total ?? "—"} claims · {grouped.length} companies
            </span>
          </div>
        </div>

        {/* ── Company Groups ───────────────────────────────────────────────── */}
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-7 h-7 animate-spin text-teal-400" />
          </div>
        ) : grouped.length === 0 ? (
          <div className="card-padded text-center text-slate-500 py-10">
            No claims match the current filters.
          </div>
        ) : (
          <div className="space-y-2">
            {grouped.map((g) => {
              const expanded = expandedCompanies.has(g.name);
              return (
                <div key={g.name} className="card overflow-hidden">
                  {/* ── Company summary row ─────────────────────────────────── */}
                  <button
                    onClick={() => toggleCompany(g.name)}
                    className={clsx(
                      "w-full text-left px-4 py-3 flex items-center gap-3 hover:bg-slate-700/30 transition-colors",
                      expanded && "bg-slate-700/20"
                    )}
                  >
                    <div className="w-8 h-8 rounded-lg bg-slate-700 flex items-center justify-center shrink-0">
                      <Building2 className="w-4 h-4 text-teal-400" />
                    </div>

                    {/* Company name */}
                    <div className="flex-1 min-w-0 text-left">
                      <p className="text-slate-200 font-semibold text-sm truncate">
                        {g.name}
                      </p>
                      <p className="text-slate-500 text-xs mt-0.5">
                        {g.claims.length} claim{g.claims.length !== 1 ? "s" : ""}
                        {" · "}
                        {g.claims[0]?.carrier ?? ""}
                      </p>
                    </div>

                    {/* Stats */}
                    <div className="hidden md:flex items-center gap-6 shrink-0">
                      <div className="text-right">
                        <p className="text-slate-500 text-[10px]">Incurred</p>
                        <p className="text-slate-200 text-sm font-semibold">
                          {fmt(g.totalIncurred)}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-slate-500 text-[10px]">Paid</p>
                        <p className="text-teal-400 text-sm font-semibold">
                          {fmt(g.totalPaid)}
                        </p>
                      </div>
                      {g.totalReserved > 0 && (
                        <div className="text-right">
                          <p className="text-slate-500 text-[10px]">Reserved</p>
                          <p className="text-amber-400 text-sm font-semibold">
                            {fmt(g.totalReserved)}
                          </p>
                        </div>
                      )}
                      {g.openCount > 0 ? (
                        <span className="text-xs bg-red-900/40 text-red-400 border border-red-700/40 px-2 py-0.5 rounded-full">
                          {g.openCount} open
                        </span>
                      ) : (
                        <span className="text-xs bg-slate-700/50 text-slate-500 border border-slate-600/40 px-2 py-0.5 rounded-full">
                          All closed
                        </span>
                      )}
                    </div>

                    <ChevronRight
                      className={clsx(
                        "w-4 h-4 text-slate-500 transition-transform shrink-0",
                        expanded && "rotate-90 text-teal-400"
                      )}
                    />
                  </button>

                  {/* ── Expanded claims table ──────────────────────────────── */}
                  {expanded && (
                    <div className="border-t border-slate-700/50 overflow-x-auto">
                      <table className="w-full text-sm min-w-[800px]">
                        <thead>
                          <tr className="border-b border-slate-700/40 bg-slate-800/40">
                            {[
                              "Claim #",
                              "Policy #",
                              "Line",
                              "Category",
                              "Date of Loss",
                              "State",
                              "Status",
                              "Paid",
                              "Reserved",
                              "Incurred",
                            ].map((h) => (
                              <th
                                key={h}
                                className="text-left text-slate-400 text-[11px] font-medium px-4 py-2.5"
                              >
                                {h}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {g.claims.map((c, i) => (
                            <tr
                              key={c.claimNumber}
                              className={clsx(
                                "border-b border-slate-700/20 hover:bg-slate-800/30 transition-colors",
                                i === g.claims.length - 1 && "border-0",
                                c.status === "Open" && "bg-red-950/10"
                              )}
                            >
                              <td className="px-4 py-2.5 font-mono text-xs text-slate-300">
                                {c.claimNumber}
                              </td>
                              <td className="px-4 py-2.5 font-mono text-xs text-slate-500">
                                {c.policyNumber}
                              </td>
                              <td className="px-4 py-2.5">
                                <span
                                  className={`text-[10px] px-1.5 py-0.5 rounded border ${LINE_COLORS[c.line] ?? ""}`}
                                >
                                  {c.line}
                                </span>
                              </td>
                              <td className="px-4 py-2.5 text-slate-300 text-xs max-w-[140px] truncate" title={c.category}>
                                {c.category}
                              </td>
                              <td className="px-4 py-2.5 text-slate-400 text-xs">
                                {c.dateOfLoss}
                              </td>
                              <td className="px-4 py-2.5 text-slate-400 text-xs">{c.state}</td>
                              <td className="px-4 py-2.5">
                                <span
                                  className={`text-[10px] px-2 py-0.5 rounded-full border ${STATUS_COLORS[c.status] ?? ""}`}
                                >
                                  {c.status}
                                </span>
                              </td>
                              <td className="px-4 py-2.5 text-slate-200 text-xs font-medium">
                                {c.totalPaid > 0 ? fmt(c.totalPaid) : "—"}
                              </td>
                              <td className="px-4 py-2.5 text-amber-400 text-xs font-medium">
                                {c.totalReserve > 0 ? fmt(c.totalReserve) : "—"}
                              </td>
                              <td className="px-4 py-2.5 text-slate-100 text-xs font-semibold">
                                {c.totalIncurred > 0 ? fmt(c.totalIncurred) : "—"}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                        {/* Company footer totals */}
                        <tfoot>
                          <tr className="border-t border-slate-700/60 bg-slate-800/50">
                            <td colSpan={7} className="px-4 py-2 text-slate-400 text-xs font-medium">
                              {g.claims.length} claims
                            </td>
                            <td className="px-4 py-2 text-slate-200 text-xs font-semibold">
                              {fmt(g.totalPaid)}
                            </td>
                            <td className="px-4 py-2 text-amber-400 text-xs font-semibold">
                              {g.totalReserved > 0 ? fmt(g.totalReserved) : "—"}
                            </td>
                            <td className="px-4 py-2 text-orange-400 text-xs font-bold">
                              {fmt(g.totalIncurred)}
                            </td>
                          </tr>
                        </tfoot>
                      </table>

                      {/* Accident descriptions for open claims */}
                      {g.claims.some((c) => c.status === "Open" && c.accidentDesc) && (
                        <div className="px-4 pb-3 pt-2 border-t border-slate-700/30 bg-slate-800/20">
                          <p className="text-slate-500 text-[10px] uppercase tracking-wider mb-2">
                            Open claim notes
                          </p>
                          <div className="space-y-1.5">
                            {g.claims
                              .filter((c) => c.status === "Open" && c.accidentDesc)
                              .map((c) => (
                                <div key={c.claimNumber} className="flex gap-2 text-xs">
                                  <span className="font-mono text-slate-500 shrink-0">
                                    {c.claimNumber}
                                  </span>
                                  <span className="text-slate-400">{c.accidentDesc}</span>
                                </div>
                              ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* ── Pagination ───────────────────────────────────────────────────── */}
        {data && data.pagination.totalPages > 1 && (
          <div className="flex items-center justify-center gap-2 pt-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page <= 1}
              className="px-3 py-1.5 text-xs rounded-lg bg-slate-700 text-slate-300 hover:bg-slate-600 disabled:opacity-40 transition-colors"
            >
              ← Prev
            </button>
            <span className="text-slate-400 text-xs">
              Page {data.pagination.page} of {data.pagination.totalPages} ·{" "}
              {data.pagination.total} claims
            </span>
            <button
              onClick={() => setPage((p) => Math.min(data.pagination.totalPages, p + 1))}
              disabled={page >= data.pagination.totalPages}
              className="px-3 py-1.5 text-xs rounded-lg bg-slate-700 text-slate-300 hover:bg-slate-600 disabled:opacity-40 transition-colors"
            >
              Next →
            </button>
          </div>
        )}
      </main>
    </>
  );
}
