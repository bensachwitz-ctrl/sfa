// ─────────────────────────────────────────────────────────────────────────────
// Fabric SQL Analytics Endpoint connection.
// Falls back to mock data automatically if FABRIC_SQL_ENDPOINT is not set.
//
// Default table names match a standard Applied Epic CSV export to Fabric.
// Rename these in your .env.local if your tables have different names:
//   FABRIC_TABLE_POLICIES=Policies
//   FABRIC_TABLE_CLAIMS=Claims
//   FABRIC_TABLE_DRIVERS=Drivers
//   FABRIC_TABLE_SAMSARA=SamsaraEvents
// ─────────────────────────────────────────────────────────────────────────────

import type { config as SqlConfig } from "mssql";

const TABLES = {
  policies: process.env.FABRIC_TABLE_POLICIES || "Policies",
  claims: process.env.FABRIC_TABLE_CLAIMS || "Claims",
  drivers: process.env.FABRIC_TABLE_DRIVERS || "Drivers",
  samsara: process.env.FABRIC_TABLE_SAMSARA || "SamsaraEvents",
};

export function isFabricConfigured(): boolean {
  return Boolean(process.env.FABRIC_SQL_ENDPOINT && process.env.FABRIC_DATABASE);
}

export function getFabricConfig(): SqlConfig {
  // Prefer service principal if available, else AAD user/password
  const useSP =
    process.env.AZURE_SP_CLIENT_ID && process.env.AZURE_SP_CLIENT_SECRET;

  return {
    server: process.env.FABRIC_SQL_ENDPOINT!,
    database: process.env.FABRIC_DATABASE!,
    authentication: useSP
      ? {
          type: "azure-active-directory-service-principal-secret" as any,
          options: {
            tenantId: process.env.AZURE_SP_TENANT_ID!,
            clientId: process.env.AZURE_SP_CLIENT_ID!,
            clientSecret: process.env.AZURE_SP_CLIENT_SECRET!,
          },
        }
      : {
          type: "azure-active-directory-password" as any,
          options: {
            userName: process.env.FABRIC_SQL_USER!,
            password: process.env.FABRIC_SQL_PASSWORD!,
          },
        },
    options: {
      encrypt: true,
      trustServerCertificate: false,
      connectTimeout: 30000,
      requestTimeout: 30000,
    },
    pool: { max: 5, min: 0, idleTimeoutMillis: 30000 },
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// SQL query templates — edit column names here to match your Fabric tables.
// ─────────────────────────────────────────────────────────────────────────────
export const SQL = {
  listCompanies: `
    SELECT DISTINCT
      AccountCode   AS id,
      AccountName   AS accountName,
      AccountCode   AS accountCode,
      DOTNumber     AS dotNumber,
      City          AS city,
      State         AS state
    FROM ${TABLES.policies}
    WHERE Status = 'Active'
    ORDER BY AccountName
  `,

  companySummary: (accountCode: string) => `
    SELECT
      p.AccountCode,
      p.AccountName,
      COUNT(DISTINCT p.PolicyNumber) AS activePolicies,
      SUM(p.WrittenPremium)          AS totalPremium,
      COUNT(c.ClaimNumber)           AS openClaims,
      ISNULL(SUM(c.PaidAmount), 0)   AS totalPaidLosses,
      ISNULL(SUM(c.ReservedAmount),0) AS totalReservedLosses
    FROM ${TABLES.policies} p
    LEFT JOIN ${TABLES.claims} c
      ON c.AccountCode = p.AccountCode AND c.Status IN ('Open','Pending')
    WHERE p.AccountCode = '${accountCode}'
      AND p.Status = 'Active'
    GROUP BY p.AccountCode, p.AccountName
  `,

  policiesByCompany: (accountCode: string) => `
    SELECT
      PolicyNumber,
      AccountCode,
      AccountName,
      Carrier,
      CoverageType,
      CONVERT(VARCHAR, EffectiveDate, 23)  AS effectiveDate,
      CONVERT(VARCHAR, ExpirationDate, 23) AS expirationDate,
      WrittenPremium,
      Status
    FROM ${TABLES.policies}
    WHERE AccountCode = '${accountCode}'
    ORDER BY ExpirationDate ASC
  `,

  claimsByCompany: (accountCode: string) => `
    SELECT
      ClaimNumber,
      PolicyNumber,
      AccountCode,
      AccountName,
      CONVERT(VARCHAR, LossDate, 23)   AS lossDate,
      CONVERT(VARCHAR, ReportDate, 23) AS reportDate,
      LossType,
      Status,
      PaidAmount,
      ReservedAmount,
      Description
    FROM ${TABLES.claims}
    WHERE AccountCode = '${accountCode}'
    ORDER BY LossDate DESC
  `,

  driversByCompany: (accountCode: string) => `
    SELECT
      DriverID        AS driverId,
      AccountCode,
      AccountName,
      DriverName      AS name,
      LicenseState    AS licenseState,
      MVRPoints       AS mvrPoints,
      RiskLevel       AS riskLevel,
      SpeedEvents30d  AS speedingEvents30d,
      HardBraking30d  AS hardBrakingEvents30d,
      SamsaraScore    AS samsaraScore,
      OpenClaims      AS openClaims
    FROM ${TABLES.drivers}
    WHERE AccountCode = '${accountCode}'
    ORDER BY MVRPoints DESC
  `,

  claimsTrend: (accountCode: string) => `
    SELECT
      FORMAT(LossDate, 'MMM ''yy') AS month,
      COUNT(*)                     AS claimCount,
      ISNULL(SUM(PaidAmount),0)    AS paidAmount,
      ISNULL(SUM(ReservedAmount),0)AS reservedAmount
    FROM ${TABLES.claims}
    WHERE AccountCode = '${accountCode}'
      AND LossDate >= DATEADD(MONTH, -12, GETDATE())
    GROUP BY FORMAT(LossDate, 'MMM ''yy'), YEAR(LossDate), MONTH(LossDate)
    ORDER BY YEAR(LossDate), MONTH(LossDate)
  `,

  lossRatio: (accountCode: string) => `
    SELECT
      p.CoverageType        AS coverage,
      SUM(p.WrittenPremium) AS premium,
      ISNULL(SUM(c.PaidAmount),0)     AS paidLosses,
      ISNULL(SUM(c.ReservedAmount),0) AS reservedLosses,
      CASE WHEN SUM(p.WrittenPremium) > 0
        THEN ROUND((ISNULL(SUM(c.PaidAmount),0) / SUM(p.WrittenPremium)) * 100, 1)
        ELSE 0 END AS lossRatio
    FROM ${TABLES.policies} p
    LEFT JOIN ${TABLES.claims} c ON c.PolicyNumber = p.PolicyNumber
    WHERE p.AccountCode = '${accountCode}'
    GROUP BY p.CoverageType
    ORDER BY premium DESC
  `,

  samsaraEvents: (accountCode: string) => `
    SELECT
      CONVERT(VARCHAR, DATEADD(DAY, -DATEPART(WEEKDAY, EventDate)+1, CAST(EventDate AS DATE)), 101) AS week,
      SUM(CASE WHEN EventType = 'Speeding' THEN 1 ELSE 0 END)           AS speeding,
      SUM(CASE WHEN EventType = 'HardBraking' THEN 1 ELSE 0 END)        AS hardBraking,
      SUM(CASE WHEN EventType = 'HarshAcceleration' THEN 1 ELSE 0 END)  AS harshAcceleration,
      SUM(CASE WHEN EventType = 'HarshCornering' THEN 1 ELSE 0 END)     AS harshCornering
    FROM ${TABLES.samsara} s
    JOIN ${TABLES.drivers} d ON d.DriverID = s.DriverID
    WHERE d.AccountCode = '${accountCode}'
      AND EventDate >= DATEADD(DAY, -91, GETDATE())
    GROUP BY DATEADD(DAY, -DATEPART(WEEKDAY, EventDate)+1, CAST(EventDate AS DATE))
    ORDER BY week
  `,

  premiumVsLosses: (accountCode: string) => `
    SELECT
      CAST(YEAR(p.EffectiveDate) AS VARCHAR) AS period,
      SUM(p.WrittenPremium)                  AS writtenPremium,
      ISNULL(SUM(c.PaidAmount),0)            AS paidLosses,
      ISNULL(SUM(c.PaidAmount + c.ReservedAmount),0) AS incurredLosses
    FROM ${TABLES.policies} p
    LEFT JOIN ${TABLES.claims} c ON c.PolicyNumber = p.PolicyNumber
    WHERE p.AccountCode = '${accountCode}'
    GROUP BY YEAR(p.EffectiveDate)
    ORDER BY YEAR(p.EffectiveDate)
  `,

  kpis: `
    SELECT
      (SELECT COUNT(*) FROM ${TABLES.policies} WHERE Status = 'Active') AS totalActivePolicies,
      (SELECT COUNT(*) FROM ${TABLES.claims}   WHERE Status IN ('Open','Pending')) AS openClaims,
      (SELECT COUNT(*) FROM ${TABLES.drivers}  WHERE RiskLevel = 'high') AS atRiskDrivers,
      (SELECT COUNT(*) FROM ${TABLES.policies}
        WHERE Status = 'Active'
          AND ExpirationDate BETWEEN GETDATE() AND DATEADD(DAY, 30, GETDATE())) AS renewalsDue30d
  `,
};
