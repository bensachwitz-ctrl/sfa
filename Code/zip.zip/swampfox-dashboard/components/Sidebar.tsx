"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useMsal } from "@azure/msal-react";
import {
  LayoutDashboard,
  FileText,
  Shield,
  Users,
  AlertTriangle,
  Building2,
  LogOut,
  ChevronRight,
} from "lucide-react";
import clsx from "clsx";

const NAV_ITEMS = [
  {
    href: "/",
    label: "Overview",
    icon: LayoutDashboard,
    exact: true,
  },
  {
    href: "/claims",
    label: "Claims",
    icon: FileText,
  },
  {
    href: "/policies",
    label: "Policies",
    icon: Shield,
  },
  {
    href: "/drivers",
    label: "Drivers",
    icon: Users,
  },
  {
    href: "/companies",
    label: "Companies & DOT",
    icon: Building2,
  },
  {
    href: "/risk-alerts",
    label: "Risk Alerts",
    icon: AlertTriangle,
  },
];

export default function Sidebar() {
  const pathname = usePathname();
  const { instance, accounts } = useMsal();

  const user = accounts[0];
  const initials = user?.name
    ? user.name
        .split(" ")
        .map((n) => n[0])
        .join("")
        .toUpperCase()
        .slice(0, 2)
    : "SF";

  const handleLogout = () => {
    instance.logoutPopup({ mainWindowRedirectUri: "/" });
  };

  return (
    <aside className="fixed left-0 top-0 h-screen w-64 bg-slate-900 border-r border-slate-700/60 flex flex-col z-50">
      {/* Logo / Brand */}
      <div className="px-6 py-5 border-b border-slate-700/60">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-teal-500 to-teal-700 flex items-center justify-center shadow-lg shadow-teal-900/50">
            <Shield className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className="text-white font-semibold text-sm leading-tight">
              Swamp Fox
            </p>
            <p className="text-teal-400 text-xs">Agency Dashboard</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
        <p className="text-slate-500 text-xs font-medium uppercase tracking-wider px-3 mb-3">
          Navigation
        </p>
        {NAV_ITEMS.map(({ href, label, icon: Icon, exact }) => {
          const active = exact ? pathname === href : pathname.startsWith(href);
          return (
            <Link
              key={href}
              href={href}
              className={clsx(
                "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 group",
                active
                  ? "bg-teal-600/20 text-teal-300 border border-teal-500/30"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800"
              )}
            >
              <Icon
                className={clsx(
                  "w-4 h-4 shrink-0",
                  active ? "text-teal-400" : "text-slate-500 group-hover:text-slate-300"
                )}
              />
              <span className="flex-1">{label}</span>
              {active && (
                <ChevronRight className="w-3.5 h-3.5 text-teal-500" />
              )}
              {label === "Risk Alerts" && (
                <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
              )}
            </Link>
          );
        })}
      </nav>

      {/* User / Logout */}
      <div className="px-3 py-4 border-t border-slate-700/60">
        <div className="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-slate-800/60 mb-2">
          <div className="w-8 h-8 rounded-full bg-teal-700 flex items-center justify-center text-xs font-bold text-white shrink-0">
            {initials}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-slate-200 text-xs font-medium truncate">
              {user?.name || "Agency User"}
            </p>
            <p className="text-slate-500 text-xs truncate">
              {user?.username || ""}
            </p>
          </div>
        </div>
        <button
          onClick={handleLogout}
          className="flex items-center gap-3 w-full px-3 py-2 rounded-lg text-slate-400 hover:text-red-400 hover:bg-red-900/20 text-sm transition-colors"
        >
          <LogOut className="w-4 h-4" />
          Sign Out
        </button>
      </div>
    </aside>
  );
}
