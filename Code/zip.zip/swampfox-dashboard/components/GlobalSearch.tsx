"use client";

import {
  useState,
  useEffect,
  useRef,
  useCallback,
  KeyboardEvent,
} from "react";
import { Search, X, Building2, FileText, AlertCircle, Loader2 } from "lucide-react";
import { useCompanySearch } from "@/contexts/CompanySearchContext";
import { searchEntities } from "@/services/dataService";
import { fetchCompanies } from "@/services/dataService";
import type { SearchResultItem, SearchResults } from "@/services/dataService";
import type { Company } from "@/lib/mockData";

// ── Helpers ───────────────────────────────────────────────────────────────────

function useDebounce<T>(value: T, delay: number): T {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return debounced;
}

const CATEGORY_LABEL: Record<string, string> = {
  company: "Companies",
  policy: "Policies",
  claim: "Claims",
};

const CATEGORY_ICON: Record<string, React.ElementType> = {
  company: Building2,
  policy: FileText,
  claim: AlertCircle,
};

const CATEGORY_ORDER = ["company", "policy", "claim"] as const;

// ── Component ─────────────────────────────────────────────────────────────────

export default function GlobalSearch() {
  const { selectedCompanies, addCompany, removeCompany, clearSelection, isSelected } =
    useCompanySearch();

  const [query, setQuery] = useState("");
  const [results, setResults] = useState<SearchResults | null>(null);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(-1);

  // Cache of all companies so we can hydrate Company objects from policy/claim hits
  const companyCacheRef = useRef<Map<string, Company>>(new Map());
  useEffect(() => {
    fetchCompanies()
      .then((list) => {
        list.forEach((c) => companyCacheRef.current.set(c.accountCode, c));
      })
      .catch(() => {});
  }, []);

  const inputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const debouncedQuery = useDebounce(query, 220);

  // ── Fetch results ──────────────────────────────────────────────────────────
  useEffect(() => {
    if (debouncedQuery.length < 2) {
      setResults(null);
      setOpen(false);
      return;
    }
    setLoading(true);
    searchEntities(debouncedQuery)
      .then((r) => {
        setResults(r);
        setOpen(true);
        setActiveIndex(-1);
      })
      .catch(() => setResults(null))
      .finally(() => setLoading(false));
  }, [debouncedQuery]);

  // ── Close on outside click ─────────────────────────────────────────────────
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(e.target as Node) &&
        inputRef.current &&
        !inputRef.current.contains(e.target as Node)
      ) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // ── Flatten results for keyboard navigation ────────────────────────────────
  const flatResults: SearchResultItem[] = results
    ? CATEGORY_ORDER.flatMap((cat) => {
        const key = cat === "company" ? "companies" : cat === "policy" ? "policies" : "claims";
        return results[key] ?? [];
      })
    : [];

  // ── Select a result ────────────────────────────────────────────────────────
  const handleSelect = useCallback(
    (item: SearchResultItem) => {
      const company =
        item.type === "company"
          ? companyCacheRef.current.get(item.accountCode) ??
            ({
              id: item.accountCode,
              accountName: item.accountName,
              accountCode: item.accountCode,
              dotNumber: item.dotNumber ?? "",
              city: "",
              state: "",
              fleetSize: 0,
              renewalDate: "",
              daysToRenewal: 0,
              saferRating: "Not Rated",
              lossRatio: 0,
              renewalScore: 0,
              totalPremium: 0,
              totalPaidLosses: 0,
              openClaims: 0,
              activePolicies: 0,
              highRiskDrivers: 0,
              totalDrivers: 0,
            } as Company)
          : companyCacheRef.current.get(item.accountCode);

      if (company) {
        if (isSelected(company.id)) {
          removeCompany(company.id);
        } else {
          addCompany(company);
        }
      }
      setQuery("");
      setResults(null);
      setOpen(false);
      inputRef.current?.focus();
    },
    [addCompany, removeCompany, isSelected]
  );

  // ── Keyboard navigation ────────────────────────────────────────────────────
  function handleKeyDown(e: KeyboardEvent<HTMLInputElement>) {
    if (!open) return;

    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActiveIndex((i) => Math.min(i + 1, flatResults.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActiveIndex((i) => Math.max(i - 1, -1));
    } else if (e.key === "Enter" && activeIndex >= 0) {
      e.preventDefault();
      handleSelect(flatResults[activeIndex]);
    } else if (e.key === "Escape") {
      setOpen(false);
      setQuery("");
    }
  }

  // ── Render dropdown items ──────────────────────────────────────────────────
  function renderCategory(
    items: SearchResultItem[],
    type: "company" | "policy" | "claim"
  ) {
    if (!items.length) return null;
    const Icon = CATEGORY_ICON[type];
    return (
      <div key={type}>
        <div className="px-3 py-1.5 text-[10px] font-semibold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
          <Icon className="w-3 h-3" />
          {CATEGORY_LABEL[type]}
        </div>
        {items.map((item) => {
          const globalIndex = flatResults.indexOf(item);
          const active = globalIndex === activeIndex;
          const selected = isSelected(item.accountCode);
          return (
            <button
              key={item.id}
              onMouseDown={(e) => {
                e.preventDefault();
                handleSelect(item);
              }}
              onMouseEnter={() => setActiveIndex(globalIndex)}
              className={[
                "w-full text-left px-3 py-2 flex items-start gap-2.5 transition-colors",
                active ? "bg-slate-700" : "hover:bg-slate-700/60",
              ].join(" ")}
            >
              <Icon className={`w-3.5 h-3.5 mt-0.5 shrink-0 ${selected ? "text-teal-400" : "text-slate-500"}`} />
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span className={`text-sm font-medium truncate ${selected ? "text-teal-300" : "text-slate-200"}`}>
                    {item.label}
                  </span>
                  {selected && (
                    <span className="shrink-0 text-[10px] font-semibold text-teal-400 bg-teal-900/40 border border-teal-700/40 rounded px-1.5 py-0.5">
                      Selected
                    </span>
                  )}
                </div>
                <span className="text-xs text-slate-500 truncate block">{item.sublabel}</span>
              </div>
            </button>
          );
        })}
      </div>
    );
  }

  const hasResults =
    results &&
    (results.companies.length > 0 ||
      results.policies.length > 0 ||
      results.claims.length > 0);

  return (
    <div className="flex flex-col gap-2 w-full max-w-2xl">
      {/* ── Search Input ──────────────────────────────────────────────────── */}
      <div className="relative">
        <div className="relative flex items-center">
          {loading ? (
            <Loader2 className="absolute left-3 w-4 h-4 text-teal-400 animate-spin pointer-events-none" />
          ) : (
            <Search className="absolute left-3 w-4 h-4 text-slate-400 pointer-events-none" />
          )}
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => {
              if (results && hasResults) setOpen(true);
            }}
            onKeyDown={handleKeyDown}
            placeholder="Search company, policy #, claim #, or DOT…"
            className="w-full h-9 pl-9 pr-4 rounded-lg bg-slate-800 border border-slate-700 text-slate-100 text-sm placeholder-slate-500 focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500/30 transition-colors"
          />
        </div>

        {/* ── Dropdown ────────────────────────────────────────────────────── */}
        {open && (
          <div
            ref={dropdownRef}
            className="absolute top-full left-0 right-0 mt-1.5 bg-slate-800 border border-slate-700 rounded-xl shadow-2xl shadow-black/40 overflow-hidden z-50"
          >
            {hasResults ? (
              <div className="py-1 max-h-80 overflow-y-auto">
                {renderCategory(results!.companies, "company")}
                {renderCategory(results!.policies, "policy")}
                {renderCategory(results!.claims, "claim")}
              </div>
            ) : (
              <div className="px-4 py-6 text-center text-slate-500 text-sm">
                No results for &ldquo;{query}&rdquo;
              </div>
            )}
            <div className="border-t border-slate-700/60 px-3 py-1.5 text-[10px] text-slate-600">
              ↑↓ navigate &nbsp;·&nbsp; Enter select &nbsp;·&nbsp; Esc close
            </div>
          </div>
        )}
      </div>

      {/* ── Selected Company Chips ────────────────────────────────────────── */}
      {selectedCompanies.length > 0 && (
        <div className="flex flex-wrap items-center gap-1.5">
          {selectedCompanies.map((c) => (
            <span
              key={c.id}
              className="inline-flex items-center gap-1 pl-2 pr-1 py-0.5 rounded-full text-xs font-medium bg-teal-900/50 border border-teal-700/50 text-teal-200"
            >
              <Building2 className="w-3 h-3 text-teal-400 shrink-0" />
              <span className="max-w-[160px] truncate">{c.accountName}</span>
              <button
                onClick={() => removeCompany(c.id)}
                className="ml-0.5 p-0.5 rounded-full hover:bg-teal-700/50 text-teal-400 hover:text-white transition-colors"
                aria-label={`Remove ${c.accountName}`}
              >
                <X className="w-2.5 h-2.5" />
              </button>
            </span>
          ))}
          {selectedCompanies.length > 1 && (
            <button
              onClick={clearSelection}
              className="text-[10px] text-slate-500 hover:text-red-400 transition-colors underline underline-offset-2 ml-0.5"
            >
              Clear all
            </button>
          )}
        </div>
      )}
    </div>
  );
}
