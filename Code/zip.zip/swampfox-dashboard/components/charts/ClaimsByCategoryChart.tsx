"use client";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";

interface DataPoint {
  category: string;
  count: number;
  incurred: number;
}

interface Props {
  data: DataPoint[];
  mode?: "count" | "incurred";
}

const COLORS = [
  "#14b8a6", "#0ea5e9", "#8b5cf6", "#f97316", "#ec4899",
  "#22c55e", "#eab308", "#ef4444", "#6366f1", "#84cc16",
];

function fmtDollar(n: number) {
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `$${(n / 1_000).toFixed(0)}K`;
  return `$${Math.round(n)}`;
}

export default function ClaimsByCategoryChart({ data, mode = "incurred" }: Props) {
  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center h-full text-slate-500 text-sm">
        No data
      </div>
    );
  }

  const sorted = [...data]
    .sort((a, b) => (mode === "incurred" ? b.incurred - a.incurred : b.count - a.count))
    .slice(0, 8);

  const dataKey = mode === "incurred" ? "incurred" : "count";

  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart
        layout="vertical"
        data={sorted}
        margin={{ top: 0, right: 40, left: 4, bottom: 0 }}
      >
        <CartesianGrid strokeDasharray="3 3" stroke="#334155" horizontal={false} />
        <XAxis
          type="number"
          tick={{ fill: "#94a3b8", fontSize: 10 }}
          axisLine={false}
          tickLine={false}
          tickFormatter={mode === "incurred" ? fmtDollar : undefined}
        />
        <YAxis
          type="category"
          dataKey="category"
          tick={{ fill: "#cbd5e1", fontSize: 10 }}
          axisLine={false}
          tickLine={false}
          width={130}
        />
        <Tooltip
          contentStyle={{
            background: "#1e293b",
            border: "1px solid #334155",
            borderRadius: 8,
            fontSize: 12,
          }}
          labelStyle={{ color: "#e2e8f0", fontWeight: 600 }}
          formatter={(value: number) => [
            mode === "incurred" ? fmtDollar(value) : value,
            mode === "incurred" ? "Total Incurred" : "Claims",
          ]}
        />
        <Bar dataKey={dataKey} radius={[0, 3, 3, 0]} maxBarSize={20}>
          {sorted.map((_, i) => (
            <Cell key={i} fill={COLORS[i % COLORS.length]} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}
