"use client";

import {
  ComposedChart,
  Area,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

interface DataPoint {
  year: string;
  incurred: number;
  paid: number;
  reserved: number;
  claims: number;
}

interface Props {
  data: DataPoint[];
}

function fmtDollar(n: number) {
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `$${(n / 1_000).toFixed(0)}K`;
  return `$${Math.round(n)}`;
}

export default function PortfolioIncurredChart({ data }: Props) {
  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center h-full text-slate-500 text-sm">
        No data
      </div>
    );
  }

  return (
    <ResponsiveContainer width="100%" height="100%">
      <ComposedChart data={data} margin={{ top: 4, right: 16, left: 8, bottom: 0 }}>
        <defs>
          <linearGradient id="gradPaid" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#14b8a6" stopOpacity={0.3} />
            <stop offset="95%" stopColor="#14b8a6" stopOpacity={0.02} />
          </linearGradient>
          <linearGradient id="gradReserved" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3} />
            <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.02} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
        <XAxis
          dataKey="year"
          tick={{ fill: "#94a3b8", fontSize: 11 }}
          axisLine={false}
          tickLine={false}
        />
        <YAxis
          yAxisId="money"
          orientation="left"
          tick={{ fill: "#94a3b8", fontSize: 11 }}
          tickFormatter={fmtDollar}
          axisLine={false}
          tickLine={false}
          width={56}
        />
        <YAxis
          yAxisId="count"
          orientation="right"
          tick={{ fill: "#94a3b8", fontSize: 11 }}
          axisLine={false}
          tickLine={false}
          width={32}
        />
        <Tooltip
          contentStyle={{
            background: "#1e293b",
            border: "1px solid #334155",
            borderRadius: 8,
            fontSize: 12,
          }}
          labelStyle={{ color: "#e2e8f0", fontWeight: 600, marginBottom: 4 }}
          formatter={(value: number, name: string) => {
            if (name === "Claims") return [value, name];
            return [fmtDollar(value), name];
          }}
        />
        <Legend
          wrapperStyle={{ fontSize: 11, color: "#94a3b8", paddingTop: 8 }}
        />
        <Area
          yAxisId="money"
          type="monotone"
          dataKey="paid"
          name="Paid"
          stroke="#14b8a6"
          strokeWidth={2}
          fill="url(#gradPaid)"
        />
        <Area
          yAxisId="money"
          type="monotone"
          dataKey="reserved"
          name="Reserved"
          stroke="#f59e0b"
          strokeWidth={2}
          fill="url(#gradReserved)"
        />
        <Line
          yAxisId="count"
          type="monotone"
          dataKey="claims"
          name="Claims"
          stroke="#e2e8f0"
          strokeWidth={1.5}
          strokeDasharray="4 2"
          dot={{ fill: "#e2e8f0", r: 2, strokeWidth: 0 }}
        />
      </ComposedChart>
    </ResponsiveContainer>
  );
}
