"use client";

import {
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

interface DataPoint {
  year: number;
  count: number;
  incurred: number;
  paid: number;
  reserved: number;
}

interface Props {
  data: DataPoint[];
}

function fmtDollar(n: number) {
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `$${(n / 1_000).toFixed(0)}K`;
  return `$${n.toFixed(0)}`;
}

export default function ClaimsByYearChart({ data }: Props) {
  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center h-full text-slate-500 text-sm">
        No data
      </div>
    );
  }

  return (
    <ResponsiveContainer width="100%" height="100%">
      <ComposedChart data={data} margin={{ top: 4, right: 16, left: 8, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
        <XAxis
          dataKey="year"
          tick={{ fill: "#94a3b8", fontSize: 11 }}
          axisLine={false}
          tickLine={false}
        />
        <YAxis
          yAxisId="count"
          orientation="left"
          tick={{ fill: "#94a3b8", fontSize: 11 }}
          axisLine={false}
          tickLine={false}
          width={28}
        />
        <YAxis
          yAxisId="money"
          orientation="right"
          tick={{ fill: "#94a3b8", fontSize: 11 }}
          tickFormatter={fmtDollar}
          axisLine={false}
          tickLine={false}
          width={52}
        />
        <Tooltip
          contentStyle={{
            background: "#1e293b",
            border: "1px solid #334155",
            borderRadius: 8,
            fontSize: 12,
          }}
          labelStyle={{ color: "#e2e8f0", fontWeight: 600, marginBottom: 4 }}
          formatter={(value: number, name: string) => {
            if (name === "Claims") return [value, name];
            return [fmtDollar(value), name];
          }}
        />
        <Legend
          wrapperStyle={{ fontSize: 11, color: "#94a3b8", paddingTop: 8 }}
        />
        <Bar
          yAxisId="count"
          dataKey="count"
          name="Claims"
          fill="#14b8a6"
          radius={[3, 3, 0, 0]}
          maxBarSize={48}
        />
        <Line
          yAxisId="money"
          dataKey="incurred"
          name="Total Incurred"
          stroke="#f97316"
          strokeWidth={2}
          dot={{ fill: "#f97316", r: 3, strokeWidth: 0 }}
          activeDot={{ r: 5 }}
        />
      </ComposedChart>
    </ResponsiveContainer>
  );
}
