"use client";

import { useIsAuthenticated, useMsal } from "@azure/msal-react";
import { InteractionStatus } from "@azure/msal-browser";
import { loginRequest } from "@/lib/msalConfig";
import { Shield, Loader2 } from "lucide-react";

export default function AuthWrapper({
  children,
}: {
  children: React.ReactNode;
}) {
  const isAuthenticated = useIsAuthenticated();
  const { instance, inProgress } = useMsal();

  if (inProgress === InteractionStatus.Startup || inProgress === InteractionStatus.HandleRedirect) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 animate-spin text-teal-500" />
          <p className="text-slate-400 text-sm">Initializing...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center px-4">
        <div className="w-full max-w-sm">
          {/* Logo */}
          <div className="flex flex-col items-center mb-8">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-teal-500 to-teal-700 flex items-center justify-center shadow-2xl shadow-teal-900/60 mb-4">
              <Shield className="w-9 h-9 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-white">Swamp Fox Agency</h1>
            <p className="text-slate-400 text-sm mt-1">
              Insurance Intelligence Dashboard
            </p>
          </div>

          {/* Sign-in card */}
          <div className="bg-slate-800/60 border border-slate-700/60 rounded-2xl p-8 backdrop-blur-sm">
            <h2 className="text-slate-100 font-semibold text-lg mb-1">
              Welcome back
            </h2>
            <p className="text-slate-400 text-sm mb-6">
              Sign in with your Microsoft 365 account to access the dashboard.
            </p>

            <button
              onClick={() => instance.loginPopup(loginRequest)}
              className="w-full flex items-center justify-center gap-3 bg-teal-600 hover:bg-teal-500 active:bg-teal-700 text-white font-medium py-3 px-4 rounded-xl transition-colors shadow-lg shadow-teal-900/40"
            >
              {/* Microsoft logo */}
              <svg viewBox="0 0 21 21" className="w-5 h-5" fill="none">
                <rect x="1" y="1" width="9" height="9" fill="#f25022" />
                <rect x="11" y="1" width="9" height="9" fill="#7fba00" />
                <rect x="1" y="11" width="9" height="9" fill="#00a4ef" />
                <rect x="11" y="11" width="9" height="9" fill="#ffb900" />
              </svg>
              Sign in with Microsoft
            </button>

            <p className="text-slate-600 text-xs text-center mt-4">
              Authorized agency personnel only
            </p>
          </div>

          {/* Footer */}
          <p className="text-slate-600 text-xs text-center mt-6">
            Swamp Fox Agency &copy; {new Date().getFullYear()} &middot; Powered by Microsoft Fabric
          </p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
