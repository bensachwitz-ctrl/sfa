"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { useMsal } from "@azure/msal-react";
import { powerBiScopes } from "@/lib/msalConfig";
import type { ReportConfig } from "@/lib/powerbiConfig";
import { Loader2, AlertTriangle, RefreshCw, Maximize2 } from "lucide-react";

interface PowerBIReportProps {
  config: ReportConfig;
  height?: string;
  className?: string;
  filterPaneVisible?: boolean;
  pageNavVisible?: boolean;
}

export default function PowerBIReport({
  config,
  height = "680px",
  className = "",
  filterPaneVisible = true,
  pageNavVisible = true,
}: PowerBIReportProps) {
  const { instance, accounts } = useMsal();
  const containerRef = useRef<HTMLDivElement>(null);
  const reportRef = useRef<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const isConfigured = Boolean(config.reportId && config.groupId);

  const embedReport = useCallback(async () => {
    if (!isConfigured) {
      setError(
        `Configure ${config.reportName} report ID in .env.local to connect to your Fabric workspace.`
      );
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);

      const account = accounts[0];
      if (!account) {
        setError("No authenticated user found.");
        setLoading(false);
        return;
      }

      const tokenResponse = await instance.acquireTokenSilent({
        scopes: powerBiScopes,
        account,
      });

      // Dynamic import — powerbi-client is browser-only
      const { models, service, factories } = await import("powerbi-client");

      const powerbiService = new service.Service(
        factories.hpmFactory,
        factories.wpmpFactory,
        factories.routerFactory
      );

      if (!containerRef.current) return;

      // Clean up previous embed
      powerbiService.reset(containerRef.current);

      const embedConfig = {
        type: "report",
        id: config.reportId,
        embedUrl: `https://app.powerbi.com/reportEmbed?reportId=${config.reportId}&groupId=${config.groupId}`,
        accessToken: tokenResponse.accessToken,
        tokenType: models.TokenType.Aad,
        settings: {
          panes: {
            filters: {
              expanded: false,
              visible: filterPaneVisible,
            },
            pageNavigation: {
              visible: pageNavVisible,
              position: models.PageNavigationPosition.Bottom,
            },
          },
          background: models.BackgroundType.Transparent,
          layoutType: models.LayoutType.Custom,
          customLayout: {
            displayOption: models.DisplayOption.FitToPage,
          },
        },
      };

      const report = powerbiService.embed(
        containerRef.current,
        embedConfig
      ) as any;

      reportRef.current = report;

      report.on("loaded", () => setLoading(false));
      report.on("rendered", () => setLoading(false));
      report.on("error", (event: any) => {
        const msg = event?.detail?.message || "Unknown error";
        setError(`Failed to load report: ${msg}`);
        setLoading(false);
      });
    } catch (err: any) {
      setError(err?.message || "Failed to embed report.");
      setLoading(false);
    }
  }, [config, accounts, instance, isConfigured, filterPaneVisible, pageNavVisible]);

  useEffect(() => {
    embedReport();
    return () => {
      if (reportRef.current) {
        try {
          reportRef.current.off("loaded");
          reportRef.current.off("rendered");
          reportRef.current.off("error");
        } catch {}
      }
    };
  }, [embedReport]);

  const openFullscreen = () => {
    if (reportRef.current) {
      try {
        reportRef.current.fullscreen();
      } catch {}
    }
  };

  return (
    <div
      className={`relative rounded-xl overflow-hidden bg-slate-800/40 border border-slate-700/50 ${className}`}
      style={{ height }}
    >
      {/* Loading overlay */}
      {loading && (
        <div className="absolute inset-0 flex items-center justify-center bg-slate-900/80 z-10 backdrop-blur-sm">
          <div className="flex flex-col items-center gap-3">
            <Loader2 className="w-8 h-8 animate-spin text-teal-400" />
            <span className="text-slate-300 text-sm">
              Loading {config.reportName}...
            </span>
          </div>
        </div>
      )}

      {/* Error / not-configured overlay */}
      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-slate-900/90 z-10 p-8">
          <div className="flex flex-col items-center gap-4 text-center max-w-md">
            <div className="w-14 h-14 rounded-full bg-amber-900/40 border border-amber-700/50 flex items-center justify-center">
              <AlertTriangle className="w-7 h-7 text-amber-400" />
            </div>
            <div>
              <p className="text-slate-200 font-semibold mb-1">
                {config.reportName}
              </p>
              <p className="text-slate-400 text-sm leading-relaxed">{error}</p>
            </div>
            {isConfigured && (
              <button
                onClick={embedReport}
                className="flex items-center gap-2 px-4 py-2 bg-teal-700 hover:bg-teal-600 text-white text-sm rounded-lg transition-colors"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Retry
              </button>
            )}
          </div>
        </div>
      )}

      {/* Fullscreen button */}
      {!loading && !error && (
        <button
          onClick={openFullscreen}
          className="absolute top-3 right-3 z-20 p-1.5 rounded-md bg-slate-900/60 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
          title="Fullscreen"
        >
          <Maximize2 className="w-3.5 h-3.5" />
        </button>
      )}

      <div ref={containerRef} className="w-full h-full" />
    </div>
  );
}
