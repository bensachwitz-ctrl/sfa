import clsx from "clsx";

export type RiskLevel = "high" | "medium" | "low" | "unknown";

interface RiskBadgeProps {
  level: RiskLevel;
  className?: string;
  pulse?: boolean;
}

const STYLES: Record<RiskLevel, string> = {
  high: "bg-red-900/50 text-red-300 border border-red-700/50",
  medium: "bg-amber-900/50 text-amber-300 border border-amber-700/50",
  low: "bg-green-900/50 text-green-300 border border-green-700/50",
  unknown: "bg-slate-700/50 text-slate-400 border border-slate-600/50",
};

const DOT_STYLES: Record<RiskLevel, string> = {
  high: "bg-red-400",
  medium: "bg-amber-400",
  low: "bg-green-400",
  unknown: "bg-slate-500",
};

const LABELS: Record<RiskLevel, string> = {
  high: "High Risk",
  medium: "Med Risk",
  low: "Low Risk",
  unknown: "Unknown",
};

export default function RiskBadge({ level, className, pulse }: RiskBadgeProps) {
  return (
    <span
      className={clsx(
        "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium",
        STYLES[level],
        className
      )}
    >
      <span
        className={clsx(
          "w-1.5 h-1.5 rounded-full",
          DOT_STYLES[level],
          pulse && level === "high" && "animate-pulse"
        )}
      />
      {LABELS[level]}
    </span>
  );
}
