"use client";

import { format } from "date-fns";
import { RefreshCw, Bell } from "lucide-react";
import GlobalSearch from "@/components/GlobalSearch";

interface TopBarProps {
  title: string;
  subtitle?: string;
}

export default function TopBar({ title, subtitle }: TopBarProps) {
  const now = new Date();

  return (
    <header className="min-h-16 border-b border-slate-700/60 bg-slate-900/80 backdrop-blur-sm flex flex-wrap items-center px-6 gap-3 sticky top-0 z-40 py-2">
      {/* ── Page Title ──────────────────────────────────────────────────── */}
      <div className="shrink-0 w-44 hidden lg:block">
        <h1 className="text-slate-100 font-semibold text-base leading-tight truncate">
          {title}
        </h1>
        {subtitle && (
          <p className="text-slate-500 text-[11px] truncate">{subtitle}</p>
        )}
      </div>

      {/* Mobile title (shown when search is below) */}
      <div className="lg:hidden flex-1 min-w-0">
        <h1 className="text-slate-100 font-semibold text-base leading-tight truncate">
          {title}
        </h1>
      </div>

      {/* ── Global Search (center, grows) ────────────────────────────────── */}
      <div className="flex-1 min-w-0 order-last lg:order-none w-full lg:w-auto">
        <GlobalSearch />
      </div>

      {/* ── Right Controls ───────────────────────────────────────────────── */}
      <div className="flex items-center gap-3 shrink-0">
        <span className="text-slate-500 text-xs hidden xl:block">
          {format(now, "EEE, MMM d yyyy")}
        </span>

        <button
          onClick={() => window.location.reload()}
          className="p-2 rounded-lg text-slate-400 hover:text-teal-400 hover:bg-slate-800 transition-colors"
          title="Refresh data"
        >
          <RefreshCw className="w-4 h-4" />
        </button>

        <button className="relative p-2 rounded-lg text-slate-400 hover:text-teal-400 hover:bg-slate-800 transition-colors">
          <Bell className="w-4 h-4" />
          <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-red-500" />
        </button>

        <div className="h-6 w-px bg-slate-700" />

        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-teal-500" />
          <span className="text-slate-400 text-xs">Live</span>
        </div>
      </div>
    </header>
  );
}
