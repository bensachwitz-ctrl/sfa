import { LucideIcon, TrendingUp, TrendingDown, Minus } from "lucide-react";
import clsx from "clsx";

type Trend = "up" | "down" | "neutral";
type Variant = "default" | "warning" | "danger" | "success";

interface StatCardProps {
  label: string;
  value: string | number;
  subtext?: string;
  icon: LucideIcon;
  trend?: Trend;
  trendValue?: string;
  variant?: Variant;
  loading?: boolean;
}

const VARIANT_STYLES: Record<Variant, string> = {
  default: "from-teal-900/30 to-transparent border-teal-700/30",
  warning: "from-amber-900/30 to-transparent border-amber-700/30",
  danger: "from-red-900/30 to-transparent border-red-700/30",
  success: "from-green-900/30 to-transparent border-green-700/30",
};

const ICON_STYLES: Record<Variant, string> = {
  default: "bg-teal-800/60 text-teal-400",
  warning: "bg-amber-800/60 text-amber-400",
  danger: "bg-red-800/60 text-red-400",
  success: "bg-green-800/60 text-green-400",
};

const TREND_ICON: Record<Trend, LucideIcon> = {
  up: TrendingUp,
  down: TrendingDown,
  neutral: Minus,
};

const TREND_COLOR: Record<Trend, string> = {
  up: "text-green-400",
  down: "text-red-400",
  neutral: "text-slate-400",
};

export default function StatCard({
  label,
  value,
  subtext,
  icon: Icon,
  trend,
  trendValue,
  variant = "default",
  loading = false,
}: StatCardProps) {
  const TrendIcon = trend ? TREND_ICON[trend] : null;

  return (
    <div
      className={clsx(
        "rounded-xl border bg-gradient-to-br p-5 backdrop-blur-sm",
        VARIANT_STYLES[variant],
        "bg-slate-800/50"
      )}
    >
      <div className="flex items-start justify-between mb-4">
        <div
          className={clsx(
            "w-10 h-10 rounded-lg flex items-center justify-center",
            ICON_STYLES[variant]
          )}
        >
          <Icon className="w-5 h-5" />
        </div>
        {trend && trendValue && TrendIcon && (
          <div className={clsx("flex items-center gap-1 text-xs font-medium", TREND_COLOR[trend])}>
            <TrendIcon className="w-3.5 h-3.5" />
            <span>{trendValue}</span>
          </div>
        )}
      </div>

      {loading ? (
        <div className="space-y-2">
          <div className="h-7 w-24 bg-slate-700/60 rounded animate-pulse" />
          <div className="h-3.5 w-32 bg-slate-700/40 rounded animate-pulse" />
        </div>
      ) : (
        <>
          <p className="text-2xl font-bold text-slate-100 leading-tight">
            {value}
          </p>
          <p className="text-slate-400 text-sm mt-0.5 font-medium">{label}</p>
          {subtext && (
            <p className="text-slate-500 text-xs mt-1">{subtext}</p>
          )}
        </>
      )}
    </div>
  );
}
